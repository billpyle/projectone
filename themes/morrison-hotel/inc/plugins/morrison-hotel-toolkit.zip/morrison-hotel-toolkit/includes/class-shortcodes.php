<?php
/**
 * Morrison_Hotel_Toolkit Shortcode Class.
 *
 * @author   Lollum
 * @category Shortcodes
 * @package  Morrison_Hotel_Toolkit/Classes
 * @version  1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'MH_TKT_Shortcodes' ) ) :

/**
 * MH_TKT_Shortcodes Class
 */
class MH_TKT_Shortcodes {

	/**
	 * Init shortcodes
	 */
	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'shortcode_scripts' ) );
		add_filter( 'the_content', array( __CLASS__, 'clean_shortcodes' ) );

		$shortcodes = array(
			'morrison_hotel_wrap'          => __CLASS__ . '::wrap',
			'morrison_hotel_column'        => __CLASS__ . '::column',
			'morrison_hotel_service'       => __CLASS__ . '::service',
			'morrison_hotel_recent_posts'  => __CLASS__ . '::recent_posts',
			'morrison_hotel_post_category' => __CLASS__ . '::post_category',
			'morrison_hotel_posts'         => __CLASS__ . '::posts',
			'morrison_hotel_toggle'        => __CLASS__ . '::toggle',
			'morrison_hotel_toggle_item'   => __CLASS__ . '::toggle_item',
			'morrison_hotel_newsletter'    => __CLASS__ . '::newsletter',
			'morrison_hotel_button'        => __CLASS__ . '::button',
			'morrison_hotel_gallery'       => __CLASS__ . '::gallery',
			'morrison_hotel_testimonials'  => __CLASS__ . '::testimonials',
			'morrison_hotel_page_boxes'    => __CLASS__ . '::page_boxes',
			'morrison_hotel_separator'     => __CLASS__ . '::separator',
			'morrison_hotel_title'         => __CLASS__ . '::title',
			'morrison_hotel_big'           => __CLASS__ . '::big',
			'morrison_hotel_map'           => __CLASS__ . '::map',
			'morrison_hotel_menu'          => __CLASS__ . '::menu',
		);

		foreach ( $shortcodes as $shortcode => $function ) {
			add_shortcode( $shortcode, $function );
		}
	}

	/**
	 * Enqueue scripts
	 *
	 * @access public
	 * @return void
	 */
	public static function shortcode_scripts() {
		wp_register_script( 'mh_tkt-flexslider', MH_TKT_PLUGIN_URL . 'assets/js/lib/jquery.flexslider.min.js', array( 'jquery' ), '2.6.0', true );
		wp_register_script( 'mh_tkt-google-maps-api', 'https://maps.googleapis.com/maps/api/js?v=3.exp', array(), '3.0', true );
		wp_register_script( 'mh_tkt-maps', MH_TKT_PLUGIN_URL . 'assets/js/morrison-hotel-toolkit-map.min.js', array( 'jquery', 'mh_tkt-google-maps-api' ), MH_TKT_VERSION, true );
	}

	/**
	 * Loop over found posts.
	 * @param  array $query_args
	 * @param  array $atts
	 * @param  string $loop_name
	 * @return string
	 */
	private static function post_loop( $query_args, $atts, $loop_name ) {
		global $morrison_hotel_toolkit_loop;

		$posts                                    = new WP_Query( apply_filters( 'morrison_hotel_shortcode_posts_query', $query_args, $atts ) );
		$columns                                  = absint( $atts[ 'columns' ] );
		$morrison_hotel_toolkit_loop[ 'columns' ] = $columns;

		ob_start();

		if ( $posts->have_posts() ) : ?>

			<ul class="posts">

				<?php while ( $posts->have_posts() ) : $posts->the_post();

					// Store loop count we're currently on
					if ( empty( $morrison_hotel_toolkit_loop[ 'loop' ] ) ) {
						$morrison_hotel_toolkit_loop[ 'loop' ] = 0;
					}

					// Increase loop count
					$morrison_hotel_toolkit_loop[ 'loop' ]++;

					// Extra post classes
					$classes = array();
					if ( 0 == ( $morrison_hotel_toolkit_loop[ 'loop' ] - 1 ) % $morrison_hotel_toolkit_loop[ 'columns' ] || 1 == $morrison_hotel_toolkit_loop[ 'columns' ] ) {
						$classes[] = 'first';
					}
					if ( 0 == $morrison_hotel_toolkit_loop[ 'loop' ] % $morrison_hotel_toolkit_loop[ 'columns' ] ) {
						$classes[] = 'last';
					}
					?>

					<li <?php post_class( $classes ); ?>>

						<?php if ( has_post_thumbnail() ) : ?>

							<?php
							switch ( $columns ) {
								case 1:
									$size = 'morrison_hotel_1140x699';
									break;

								case 2:
									$size = 'morrison_hotel_815x500';
									break;

								default:
									$size = 'morrison_hotel_480x294';
									break;
							}
							?>

							<a class="post-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true">
								<?php the_post_thumbnail( $size, array( 'alt' => get_the_title() ) ); ?>
							</a><!-- .post-thumbnail -->

						<?php endif; ?>

						<?php the_title( '<h4 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h4>' ); ?>

						<div class="entry-meta">
							<?php
							$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
							if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
								$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
							}

							$time_string = sprintf( $time_string,
								esc_attr( get_the_date( 'c' ) ),
								esc_html( get_the_date() ),
								esc_attr( get_the_modified_date( 'c' ) ),
								esc_html( get_the_modified_date() )
							);

							$posted_on = sprintf(
								esc_html_x( 'Posted on %s', 'post date', 'morrison-hotel' ),
								'<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a>'
							);

							$byline = sprintf(
								esc_html_x( 'by %s', 'post author', 'morrison-hotel' ),
								'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>'
							);

							echo '<span class="posted-on">' . $posted_on . '</span><span class="byline"> ' . $byline . '</span>'; // WPCS: XSS OK.
							?>
						</div><!-- .entry-meta -->

						<div class="entry-summary">
							<?php the_excerpt(); ?>
						</div><!-- .entry-summary -->

					</li>

				<?php endwhile; // end of the loop. ?>

			</ul>

		<?php endif;

		$morrison_hotel_toolkit_loop[ 'loop' ] = $morrison_hotel_toolkit_loop[ 'columns' ] = '';
		wp_reset_postdata();

		return '<div class="morrison-hotel-loop columns-' . $columns . '">' . ob_get_clean() . '</div>';
	}

	/**
	 * Wrap shortcode.
	 *
	 * @access public
	 * @param array @atts
	 * @param string @content
	 * @return string
	 */
	public static function wrap($atts, $content = null ) {
		ob_start();
		?>

		<div class="morrison-hotel-wrap">
			<?php echo do_shortcode( wp_kses_post( $content ) ); ?>
		</div>

		<?php
		$html = ob_get_clean();

		return apply_filters( 'morrison_hotel_toolkit_wrap_shortcode', $html );
	}

	/**
	 * Column shortcode.
	 *
	 * @access public
	 * @param array @atts
	 * @param string @content
	 * @return string
	 */
	public static function column( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'column' => 'one-third',
			'last'   => false
		), $atts) );

		ob_start();
		?>

		<div class="morrison-hotel-column morrison-hotel-column-<?php echo esc_attr( $column ); ?> <?php echo $last ? 'morrison-hotel-last-column' : ''; ?>">
			<?php echo do_shortcode( wp_kses_post( $content ) ); ?>
		</div>

		<?php if ( $last ) : ?>
			<div class="clear"></div>
		<?php endif;

		$html = ob_get_clean();

		return apply_filters( 'morrison_hotel_toolkit_column_shortcode', $html );
	}

	/**
	 * Service shortcode.
	 *
	 * @access public
	 * @param array @atts
	 * @param string @content
	 * @return string
	 */
	public static function service( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'column' => 'one-third',
			'title'  => '',
			'icon'   => '',
			'image'  => false,
			'link'   => false,
			'last'   => false
		), $atts) );

		ob_start();
		?>

		<div class="morrison-hotel-service morrison-hotel-column morrison-hotel-column-<?php echo esc_attr( $column ); ?> <?php echo $last ? 'morrison-hotel-last-column' : ''; ?>">

			<?php if ( $link ) : ?>
				<a href="<?php echo esc_url( $link ); ?>" class="service-icon">
			<?php else : ?>
				<span class="service-icon">
			<?php endif; ?>

			<?php if ( $image ) : ?>
				<img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $title ); ?>">
			<?php else : ?>
				<i class="fa fa-<?php echo esc_attr( $icon ); ?>"></i>
			<?php endif; ?>

			<?php if ( $link ) : ?>
				</a>
			<?php else : ?>
				</span>
			<?php endif; ?>

			<h4><?php echo esc_html( $title ); ?></h4>

			<div class="morrison-hotel-service-content"><?php echo do_shortcode( wp_kses_post( $content ) ); ?></div>
		</div>

		<?php if ( $last ) : ?>
			<div class="clear"></div>
		<?php endif;

		$html = ob_get_clean();

		return apply_filters( 'morrison_hotel_toolkit_service_shortcode', $html );
	}

	/**
	 * Recent posts shortcode.
	 *
	 * @access public
	 * @param array @atts
	 * @return string
	 */
	public static function recent_posts( $atts ) {
		$atts = shortcode_atts( array(
			'per_page' 	=> '4',
			'columns' 	=> '4',
			'orderby' 	=> 'date',
			'order' 	=> 'desc'
		), $atts );

		$query_args = array(
			'post_type'           => 'post',
			'post_status'         => 'publish',
			'ignore_sticky_posts' => 1,
			'posts_per_page'      => $atts[ 'per_page' ],
			'orderby'             => $atts[ 'orderby' ],
			'order'               => $atts[ 'order' ]
		);

		return self::post_loop( $query_args, $atts, 'recent_posts' );
	}

	/**
	 * Post category shortcode.
	 *
	 * @access public
	 * @param array @atts
	 * @return string
	 */
	public static function post_category( $atts ) {
		$atts = shortcode_atts( array(
			'per_page' => '4',
			'columns'  => '4',
			'category' => '',  // Slugs
		), $atts );

		if ( ! $atts[ 'category' ] ) {
			return '';
		}

		$query_args = array(
			'post_type'           => 'post',
			'posts_per_page'      => $atts[ 'per_page' ],
			'post_status'         => 'publish',
			'category_name'       => $atts[ 'category' ],
			'ignore_sticky_posts' => 1
		);

		return self::post_loop( $query_args, $atts, 'post_category' );
	}

	/**
	 * List multiple posts shortcode.
	 *
	 * @access public
	 * @param array @atts
	 * @return string
	 */
	public static function posts( $atts ) {
		$atts = shortcode_atts( array(
			'columns' => '4',
			'orderby' => 'title',
			'order'   => 'asc',
			'ids'     => '',
		), $atts );

		if ( ! $atts[ 'ids' ] ) {
			return '';
		}

		$query_args = array(
			'post_type'           => 'post',
			'posts_per_page'      => -1,
			'post_status'         => 'publish',
			'orderby'             => $atts[ 'orderby' ],
			'order'               => $atts[ 'order' ],
			'ignore_sticky_posts' => 1
		);

		if ( ! empty( $atts[ 'ids' ] ) ) {
			$ids                      = explode( ',', $atts[ 'ids' ] );
			$ids                      = array_map( 'trim', $ids );
			$ids                      = array_map( 'absint', $ids );
			$query_args[ 'post__in' ] = $ids;
			$query_args[ 'orderby' ]  = 'post__in';
		}

		return self::post_loop( $query_args, $atts, 'posts' );
	}

	/**
	 * Toggle shortcode.
	 *
	 * @access public
	 * @param array @atts
	 * @param string @content
	 * @return string
	 */
	public static function toggle( $atts, $content = null ) {
		ob_start();
		?>

		<div class="morrison-hotel-toggle">
			<?php echo do_shortcode( wp_kses_post( $content ) ); ?>
		</div>

		<?php
		$html = ob_get_clean();

		return apply_filters( 'morrison_hotel_toolkit_toggle_shortcode', $html );
	}

	/**
	 * Toggle item shortcode.
	 *
	 * @access public
	 * @param array @atts
	 * @param string @content
	 * @return string
	 */
	public static function toggle_item( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'title' => '',
			'state' => 'close'
		), $atts) );

		ob_start();
		?>

		<div class="morrison-hotel-toggle-header <?php echo esc_attr( $state ); ?>"><?php echo esc_html( $title ); ?></div>
		<div class="morrison-hotel-toggle-content" data-toggle="<?php echo esc_attr( $state ); ?>">
			<p><?php echo do_shortcode( wp_kses_post( $content ) ); ?></p>
		</div>

		<?php
		$html = ob_get_clean();

		return apply_filters( 'morrison_hotel_toolkit_toggle_list_shortcode', $html );
	}

	/**
	 * Newsletter shortcode.
	 *
	 * @access public
	 * @param array @atts
	 * @return string
	 */
	public static function newsletter( $atts ) {
		extract( shortcode_atts( array(
			'display_name' => 'yes',
			'email'        => '',
			'confirm'      => 'welcome-email',
			'btn_text'     => 'Subscribe',
			'list_id'      => ''
		), $atts) );

		ob_start();
		?>

		<div class="morrison-hotel-newsletter">
			<form class="morrison-hotel-newsletter-form" name="morrison-hotel-newsletter-form" method="post" data-name="<?php echo esc_attr( $display_name ); ?>" data-confirm="<?php echo esc_attr( $confirm ); ?>">

				<?php if ( $display_name == 'yes' ) : ?>
					<p class="morrison-hotel-newsletter-field morrison-hotel-newsletter-field-first">
						<label><?php esc_html_e( 'First Name', 'morrison-hotel-toolkit' ); ?></label>
						<input type="text" placeholder="<?php esc_attr_e( 'First Name', 'morrison-hotel-toolkit' ); ?>" class="morrison-hotel-newsletter-first-name">
					</p>

					<p class="morrison-hotel-newsletter-field morrison-hotel-newsletter-field-last">
						<label><?php esc_html_e( 'Last Name', 'morrison-hotel-toolkit' ); ?></label>
						<input type="text" placeholder="<?php esc_attr_e( 'Last Name', 'morrison-hotel-toolkit' ); ?>" class="morrison-hotel-newsletter-last-name">
					</p>
				<?php endif; ?>

				<p class="morrison-hotel-newsletter-field">
					<label><?php esc_html_e( 'Email Address', 'morrison-hotel-toolkit' ); ?></label>
					<input type="text" placeholder="<?php esc_attr_e( 'Email Address', 'morrison-hotel-toolkit' ); ?>" class="morrison-hotel-newsletter-email">
				</p>

				<input type="hidden" class="morrison-hotel-newsletter-list-id" value="<?php echo esc_attr( $list_id ); ?>" />

				<input type="submit" value="<?php echo esc_attr( $btn_text ); ?>" data-wait-text="<?php esc_attr_e( 'Please wait...', 'morrison-hotel-toolkit' ); ?>" class="morrison-hotel-newsletter-button">

			</form>

			<div class="morrison-hotel-newsletter-response"></div>

		</div>

		<?php
		$html = ob_get_clean();

		wp_enqueue_script( 'mh_tkt-mailchimp' );

		return apply_filters( 'morrison_hotel_toolkit_newsletter_shortcode', $html );
	}

	/**
	 * Button shortcode.
	 *
	 * @access public
	 * @param array @atts
	 * @return string
	 */
	public static function button( $atts ) {
		$atts = shortcode_atts( array(
			'link'   => '',
			'text'   => '',
			'target' => '_self',
		), $atts );

		ob_start();
		?>

		<a href="<?php echo esc_url( $atts[ 'link' ] ); ?>" target="<?php echo esc_attr( $atts[ 'target' ] ); ?>" class="button"><?php echo esc_html( $atts[ 'text' ] ); ?></a>

		<?php
		$html = ob_get_clean();

		return apply_filters( 'morrison_hotel_toolkit_button_shortcode', $html );
	}

	/**
	 * Gallery shortcode.
	 *
	 * @access public
	 * @param array @atts
	 * @return string
	 */
	public static function gallery( $atts ) {
		$atts = shortcode_atts( array(
			'ids'   => '',
			'speed' => '',
		), $atts );

		if ( ! $atts[ 'ids' ] ) {
			return '';
		}

		$images = explode( ',', $atts[ 'ids' ] );
		$images = array_map( 'absint', $images );

		$speed = $atts[ 'speed' ] ? $atts[ 'speed' ] : '4000';

		ob_start();
		?>

		<div class="morrison-hotel-gallery flexslider" data-speed="<?php echo absint( $speed ); ?>">

			<ul class="slides">

				<?php foreach ( $images as $image ) :
					$attachment   = get_post( intval( $image ) );
					$alt          = get_post_meta( $attachment->ID, '_wp_attachment_image_alt', true );
					$img_obj      = wp_get_attachment_image_src( $image, 'morrison_hotel_1140x699' );
					$image_srcset = function_exists( 'wp_get_attachment_image_srcset' ) ? wp_get_attachment_image_srcset( $image, 'morrison_hotel_1140x699' ) : false;
					$image_sizes  = function_exists( 'wp_get_attachment_image_sizes' ) ? wp_get_attachment_image_sizes( $image, 'morrison_hotel_1140x699' ) : false;
					?>
					<li>
						<img src="<?php echo esc_url( $img_obj[ 0 ] ); ?>" width="<?php echo esc_attr( $img_obj[ 1 ] ); ?>" height="<?php echo esc_attr( $img_obj[ 2 ] ); ?>" <?php echo $image_srcset ? 'srcset="' . esc_attr( $image_srcset ) . '"' : ''; ?> <?php echo $image_sizes ? 'sizes="' . esc_attr( $image_sizes ) . '"' : ''; ?> alt="<?php echo esc_attr( $alt ); ?>">
					</li>
				<?php endforeach; ?>

			</ul>
		</div>

		<?php
		$html = ob_get_clean();

		wp_enqueue_script( 'mh_tkt-flexslider' );

		return apply_filters( 'morrison_hotel_toolkit_gallery_shortcode', $html );
	}

	/**
	 * Testimonials shortcode.
	 *
	 * @access public
	 * @param array @atts
	 * @return string
	 */
	public static function testimonials( $atts, $content = null ) {
		$atts = shortcode_atts( array(
			'title'  => '',
			'speed'  => '4000'
		), $atts );

		$speed = $atts[ 'speed' ];

		// remove <p>
		$content = str_replace( '<p>', '', $content );

		// split the content into blocks and remove empty strings
		$blocks = preg_split( '#(<\/p>|<br \/>|<br\/>|<br>)#', $content );
		$blocks = array_filter( $blocks, 'strlen' );

		foreach ( $blocks as $key => $block ) {
			$blocks[ $key ] = trim( $block );
		}

		ob_start();

		?>

		<div class="morrison-hotel-testimonials flexslider" data-speed="<?php echo absint( $speed ); ?>">

			<?php if ( $atts[ 'title' ] ) : ?>

				<h3><?php echo esc_html( $atts[ 'title' ] ); ?></h3>

			<?php endif ?>

			<ul class="slides">

			<?php
			$open = false;
			foreach ( $blocks as $key => $block ) {

				if ( 0 === strpos( $block, '#' ) ) : ?>

					<?php if ( $open ) : ?>
						</blockquote></li>
					<?php
					$open = false;
					endif; ?>

					<li><blockquote>
					<?php $open = true; ?>

					<p><?php echo esc_html( substr( $block, 1 ) ); ?></p>
				<?php endif;

				if ( 0 === strpos( $block, '*' ) ) : ?>
					<cite><?php echo esc_html( substr( $block, 1 ) ); ?></cite>
				<?php endif;

				if ( 0 === strpos( $block, '=' ) ) : ?>
					<span class="testimonial-source">- <?php echo esc_html( substr( $block, 1 ) ); ?></span>
				<?php endif;

			} ?>

			<?php if ( $open ) : ?>
				</blockquote></li>
			<?php
			$open = false;
			endif; ?>

			</ul>
		</div>

		<?php

		$html = ob_get_clean();

		wp_enqueue_script( 'mh_tkt-flexslider' );

		return apply_filters( 'morrison_hotel_toolkit_testimonials_shortcode', $html );
	}

	/**
	 * Page-Boxes shortcode.
	 *
	 * @access public
	 * @param array @atts
	 * @return string
	 */
	public static function page_boxes( $atts ) {
		$atts = shortcode_atts( array(
			'orderby' => 'title',
			'order'   => 'asc',
			'ids'     => '',
			'per_page'   => 2,
		), $atts );

		$query_args = array(
			'post_type'           => 'page',
			'post_status'         => 'publish',
			'orderby'             => $atts[ 'orderby' ],
			'order'               => $atts[ 'order' ],
			'ignore_sticky_posts' => 1
		);

		if ( ! empty( $atts[ 'ids' ] ) ) {
			$ids                            = explode( ',', $atts[ 'ids' ] );
			$ids                            = array_map( 'trim', $ids );
			$ids                            = array_map( 'absint', $ids );
			$query_args[ 'post__in' ]       = $ids;
			$query_args[ 'orderby' ]        = 'post__in';
			$query_args[ 'posts_per_page' ] = -1;
		} else {
			$query_args[ 'posts_per_page' ] = $atts[ 'per_page' ];
		}

		ob_start();

		$pages = new WP_Query( $query_args );

		if ( $pages->have_posts() ) : ?>

		<div class="morrison-hotel-page-boxes">

			<?php while ( $pages->have_posts() ) : $pages->the_post(); ?>

				<div class="morrison-hotel-page-boxes-row <?php echo has_post_thumbnail() ? 'has-thumbnail' : 'has-not-thumbnail' ?>">

					<?php if ( has_post_thumbnail() ) : ?>

						<a class="post-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true">
							<?php the_post_thumbnail( 'morrison_hotel_570x570', array( 'alt' => get_the_title() ) ); ?>
						</a><!-- .post-thumbnail -->

					<?php endif; ?>

					<div class="morrison-hotel-page-boxes-content">

						<?php the_title( '<h4><a href="' . esc_url( get_permalink() ) . '">', '</a></h4>' ); ?>

						<div class="morrison-hotel-page-boxes-summary">
							<?php the_excerpt(); ?>
						</div><!-- .entry-summary -->

						<a href="<?php the_permalink(); ?>" class="view-more-link"><?php esc_html_e( 'Read more', 'morrison-hotel-toolkit' ); ?></a>

					</div>

				</div>

			<?php endwhile; // end of the loop. ?>

		</div>

		<?php
		endif;
		wp_reset_postdata();

		$html = ob_get_clean();

		return apply_filters( 'morrison_hotel_toolkit_page_boxes_shortcode', $html );
	}

	/**
	 * Title shortcode.
	 *
	 * @access public
	 * @param array @atts
	 * @param string @content
	 * @return string
	 */
	public static function title( $atts, $content = null ) {
		$atts = shortcode_atts( array(
			'border'    => 'yes',
			'alignment' => 'center'
		), $atts );

		ob_start();
		?>

		<h2 class="morrison-hotel-title <?php echo esc_attr( $atts[ 'alignment' ] ); ?> border-<?php echo esc_attr( $atts[ 'border' ] ); ?>"><?php echo do_shortcode( wp_kses_post( $content ) ); ?></h2>

		<?php
		$html = ob_get_clean();

		return apply_filters( 'morrison_hotel_toolkit_title_shortcode', $html );
	}

	/**
	 * Separator shortcode.
	 *
	 * @access public
	 * @return string
	 */
	public static function separator() {
		ob_start();
		?>

		<div class="morrison-hotel-separator"></div>

		<?php
		$html = ob_get_clean();

		return apply_filters( 'morrison_hotel_toolkit_separator_shortcode', $html );
	}

	/**
	 * Big shortcode.
	 *
	 * @access public
	 * @param array @atts
	 * @param string @content
	 * @return string
	 */
	public static function big( $atts, $content = null ) {
		$atts = shortcode_atts( array(
			'alignment' => 'center'
		), $atts );

		ob_start();
		?>

		<div class="morrison-hotel-big <?php echo esc_attr( $atts[ 'alignment' ] ); ?>"><?php echo do_shortcode( wp_kses_post( $content ) ); ?></div>

		<?php
		$html = ob_get_clean();

		return apply_filters( 'morrison_hotel_toolkit_big_shortcode', $html );
	}

	/**
	 * Map shortcode.
	 *
	 * @access public
	 * @param array @atts
	 * @return string
	 */
	public static function map( $atts ) {
		$atts = shortcode_atts( array(
			'latitude'  => '',
			'longitude' => '',
			'hue'       => '',
			'zoom'      => '15',
			'size'      => 'normal',
			'marker'    => 'yes'
		), $atts );

		ob_start();
		?>

		<div class="map-canvas-wrapper" data-hue="<?php echo esc_attr( $atts[ 'hue' ] ); ?>" data-lat="<?php echo esc_attr( $atts[ 'latitude' ] ); ?>" data-lng="<?php echo esc_attr( $atts[ 'longitude' ] ); ?>" data-zoom="<?php echo esc_attr( $atts[ 'zoom' ] ); ?>" data-marker="marker-<?php echo esc_attr( $atts[ 'marker' ] ); ?>">

			<div class="map-canvas <?php echo esc_attr( $atts[ 'size' ] ); ?>"></div>

		</div>

		<?php
		$html = ob_get_clean();

		wp_enqueue_script( 'mh_tkt-maps' );

		return apply_filters( 'morrison_hotel_toolkit_map_shortcode', $html );
	}

	/**
	 * Menu shortcode.
	 *
	 * @access public
	 * @param array @atts
	 * @param string @content
	 * @return string
	 */
	public static function menu( $atts, $content = null ) {
		$atts = shortcode_atts( array(
			'title'  => ''
		), $atts );

		// remove <p>
		$content = str_replace( '<p>', '', $content );

		// split the content into blocks and remove empty strings
		$blocks = preg_split( '#(<\/p>|<br \/>|<br\/>|<br>)#', $content );
		$blocks = array_filter( $blocks, 'strlen' );

		foreach ( $blocks as $key => $block ) {
			$blocks[ $key ] = trim( $block );
		}

		ob_start();
		?>

		<div class="morrison-hotel-menu">
			<?php if ( $atts[ 'title' ] ) : ?>
				<h4><?php echo esc_html( $atts[ 'title' ] ); ?></h4>
			<?php endif; ?>

			<ul class="dish-section">

			<?php
			$open = false;
			foreach ( $blocks as $key => $block ) {

				if ( 0 === strpos( $block, '#' ) ) : ?>

					<?php if ( $open ) : ?>
						</li><!-- .dish-item -->
					<?php
					$open = false;
					endif; ?>

					<li>
					<?php $open = true; ?>

					<span class="dish-name"><?php echo esc_html( substr( $block, 1 ) ); ?></span>
				<?php endif;

				if ( 0 === strpos( $block, '*' ) ) : ?>
					<span class="dish-description"><?php echo esc_html( substr( $block, 1 ) ); ?></span>
				<?php endif;

				if ( 0 === strpos( $block, '=' ) ) : ?>
					<span class="dish-price"><?php echo esc_html( substr( $block, 1 ) ); ?></span>
				<?php endif;

			} ?>

			<?php if ( $open ) : ?>
				</li><!-- .dish-item -->
			<?php
			$open = false;
			endif; ?>

			</ul><!-- .dish-section -->
		</div>

		<?php
		$html = ob_get_clean();

		return apply_filters( 'morrison_hotel_toolkit_menu_shortcode', $html );
	}

	/**
	 * Clean shortcode output.
	 *
	 * @access public
	 * @param string @content
	 * @return string
	 */
	public static function clean_shortcodes( $content ) {
		$array = array (
			'<p>[' => '[',
			']</p>' => ']',
			']<br />' => ']'
		);

		$content = strtr( $content, $array );

		return $content;
	}
}

endif;
