<?php
/**
 * Admin Functions.
 *
 * @author   Lollum
 * @category Shortcodes
 * @package  Morrison_Hotel_Toolkit/Admin
 * @version  1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'MH_TKT_Admin' ) ) :

/**
 * MH_TKT_Admin Class
 */
class MH_TKT_Admin {

	/**
	 * Initialize the class and set its properties.
	 *
	 * @access public
	 * @return MH_TKT_Admin
	 */
	public function __construct() {
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
		add_action( 'init', array( $this, 'add_button' ) );
	}

	/**
	 * Enqueue admin scripts and styles.
	 *
	 * @access public
	 */
	public function admin_scripts( $hook ) {
		if ( $hook == 'post-new.php' || $hook == 'post.php' ) {
			wp_enqueue_style( 'mh_tkt-admin-css', MH_TKT_PLUGIN_URL . 'assets/css/morrison-hotel-toolkit-admin.css', array(), MH_TKT_PLUGIN_URL );
			wp_enqueue_script( 'mh_tkt-admin-js', MH_TKT_PLUGIN_URL . 'assets/js/morrison-hotel-toolkit-admin.min.js', array( 'jquery', 'jquery-ui-sortable' ), MH_TKT_VERSION, true );
		}
	}

	/**
	 * Register TinyMCE button.
	 *
	 * @access public
	 */
	public function add_button() {
		// check user permissions
		if ( ! current_user_can( 'edit_posts' ) && ! current_user_can( 'edit_pages' ) ) {
			return;
		}

		// check if WYSIWYG is enabled
		if ( get_user_option( 'rich_editing' ) == 'true' ) {
			add_filter( 'mce_external_plugins', array( $this, 'add_tinymce_plugin' ) );
			add_filter( 'mce_buttons', array( $this, 'register_button' ) );
		}

		add_action( 'admin_print_footer_scripts', array( $this, 'add_quicktags' ) );
	}

	/**
	 * Add button to the editor.
	 *
	 * @access public
	 * @param array $buttons
	 * @return array
	 */
	public function register_button( $buttons ) {
		array_push( $buttons, 'morrison_hotel_toolkit_shortcodes_btn' );
		return $buttons;
	}

	/**
	 * Add plugin to TinyMCE.
	 *
	 * @since 1.0.0
	 * @access public
	 * @param array $plugin_array
	 * @return array
	 */
	public function add_tinymce_plugin( $plugin_array ) {
		$plugin_array[ 'morrison_hotel_toolkit_shortcodes_btn' ] = MH_TKT_PLUGIN_URL . 'assets/js/morrison-hotel-toolkit-shortcodes-admin.min.js';
		return $plugin_array;
	}


	// add more buttons to the html editor
	public function add_quicktags() {
	    if ( wp_script_is( 'quicktags' ) ) {
		?>
		    <script type="text/javascript">
			QTags.addButton('mh_tkt_quicktag_wrap', 'MH - Wrap', mh_tkt_show_wrap);
			QTags.addButton('mh_tkt_quicktag_title', 'MH - Title', mh_tkt_show_title);
			QTags.addButton('mh_tkt_quicktag_separator', 'MH - Separator', mh_tkt_show_separator);
			QTags.addButton('mh_tkt_quicktag_big', 'MH - Big', mh_tkt_show_big);
			QTags.addButton('mh_tkt_quicktag_columns', 'MH - Columns', mh_tkt_show_columns);
			QTags.addButton('mh_tkt_quicktag_services', 'MH - Services', mh_tkt_show_services);
			QTags.addButton('mh_tkt_quicktag_toggle', 'MH - Toggle', mh_tkt_show_toggle);
			QTags.addButton('mh_tkt_quicktag_newsletter', 'MH - Newsletter', mh_tkt_show_newsletter);
			QTags.addButton('mh_tkt_quicktag_gallery', 'MH - Gallery', mh_tkt_show_gallery);
			QTags.addButton('mh_tkt_quicktag_page_boxes', 'MH - Page-Boxes', mh_tkt_show_page_boxes);
			QTags.addButton('mh_tkt_quicktag_menu', 'MH - Menu', mh_tkt_show_menu);
			QTags.addButton('mh_tkt_quicktag_testimonials', 'MH - Testimonials', mh_tkt_show_testimonials);
			QTags.addButton('mh_tkt_quicktag_button', 'MH - Button', mh_tkt_show_button);
			QTags.addButton('mh_tkt_quicktag_map', 'MH - Map', mh_tkt_show_map);
			QTags.addButton('mh_tkt_quicktag_recent_rooms', 'MH - Recent Rooms', mh_tkt_show_recent_rooms);
			QTags.addButton('mh_tkt_quicktag_rooms', 'MH - Rooms', mh_tkt_show_rooms);
			QTags.addButton('mh_tkt_quicktag_room_type', 'MH - Room Type', mh_tkt_show_room_type);
			QTags.addButton('mh_tkt_quicktag_recent_posts', 'MH - Recent Posts', mh_tkt_show_recent_posts);
			QTags.addButton('mh_tkt_quicktag_posts', 'MH - Posts', mh_tkt_show_posts);
			QTags.addButton('mh_tkt_quicktag_post_category', 'MH - Post Category', mh_tkt_show_post_category);

			function mh_tkt_show_wrap() {
				QTags.insertContent('[morrison_hotel_wrap]\n\nLorem ipsum dolor sit amet...\n\n[/morrison_hotel_wrap]\n\n');
			}

			function mh_tkt_show_title() {
				QTags.insertContent('[morrison_hotel_title alignment="center" border="yes"]Your title here[/morrison_hotel_title]\n\n');
			}

			function mh_tkt_show_separator() {
				QTags.insertContent('[morrison_hotel_separator]\n\n');
			}

			function mh_tkt_show_big() {
				QTags.insertContent('[morrison_hotel_big alignment="center"]\n\nLorem ipsum dolor sit amet...\n\n[/morrison_hotel_big]\n\n');
			}

			function mh_tkt_show_columns() {
				QTags.insertContent('[morrison_hotel_column column="one-half"]\n\nLorem ipsum dolor sit amet...\n\n[/morrison_hotel_column]\n[morrison_hotel_column column="one-half" last="true"]\n\nLorem ipsum dolor sit amet...\n\n[/morrison_hotel_column]\n\n');
			}

			function mh_tkt_show_services() {
				QTags.insertContent('[morrison_hotel_service column="one-half" title="Service title here..." icon="fa fa-diamond"]\n\nLorem ipsum dolor sit amet...\n\n[/morrison_hotel_service]\n[morrison_hotel_service column="one-half" last="true" title="Service title here..." icon="fa fa-diamond"]\n\nLorem ipsum dolor sit amet...\n\n[/morrison_hotel_service]\n\n');
			}

			function mh_tkt_show_toggle() {
				QTags.insertContent('[morrison_hotel_toggle]\n\n[morrison_hotel_toggle_item title="Toggle title here..." state="close"]\nLorem ipsum dolor sit amet...\n[/morrison_hotel_toggle_item]\n\n[morrison_hotel_toggle_item title="Toggle title here..." state="close"]\nLorem ipsum dolor sit amet...\n[/morrison_hotel_toggle_item]\n\n[/morrison_hotel_toggle]\n\n');
			}

			function mh_tkt_show_newsletter() {
				QTags.insertContent('[morrison_hotel_newsletter display_name="yes" confirm="welcome-email" list_id="" btn_text="Subscribe"]\n\n');
			}

			function mh_tkt_show_gallery() {
				QTags.insertContent('[morrison_hotel_gallery ids="" speed="4000"]\n\n');
			}

			function mh_tkt_show_page_boxes() {
				QTags.insertContent('[morrison_hotel_page_boxes ids=""]\n\n');
			}

			function mh_tkt_show_menu() {
				QTags.insertContent('[morrison_hotel_menu title="Section title"]\n\n#Dish name\n*Dish description\n=$0.00\n\n#Dish name\n*Dish description\n=$0.00\n\n[/morrison_hotel_menu]\n\n');
			}

			function mh_tkt_show_testimonials() {
				QTags.insertContent('[morrison_hotel_testimonials title="Testimonials title here..."]\n\n#Testimonial text\n*Testimonial author\n=Tagline\n\n#Testimonial text\n*Testimonial author\n=Tagline\n\n[/morrison_hotel_testimonials]\n\n');
			}

			function mh_tkt_show_button() {
				QTags.insertContent('[morrison_hotel_button link="http://example.com/" text="Button" target="_self"]\n\n');
			}

			function mh_tkt_show_map() {
				QTags.insertContent('[morrison_hotel_map latitude="" longitude="" zoom="15" size="normal" marker="yes" hue=""]\n\n');
			}

			function mh_tkt_show_recent_rooms() {
				QTags.insertContent('[hotelier_recent_rooms per_page="6" columns="3"]\n\n');
			}

			function mh_tkt_show_rooms() {
				QTags.insertContent('[hotelier_rooms ids="" columns="3"]\n\n');
			}

			function mh_tkt_show_room_type() {
				QTags.insertContent('[hotelier_room_type category="" per_page="3" columns="3"]\n\n');
			}

			function mh_tkt_show_recent_posts() {
				QTags.insertContent('[morrison_hotel_recent_posts per_page="3" columns="3"]\n\n');
			}

			function mh_tkt_show_posts() {
				QTags.insertContent('[morrison_hotel_posts ids="" columns="3"]\n\n');
			}

			function mh_tkt_show_post_category() {
				QTags.insertContent('[morrison_hotel_post_category category="" per_page="3" columns="3"]\n\n');
			}
		    </script>
		<?php
	    }
	}


}

endif;

return new MH_TKT_Admin();
