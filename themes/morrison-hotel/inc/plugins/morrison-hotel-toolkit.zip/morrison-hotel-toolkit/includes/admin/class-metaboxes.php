<?php
/**
 * Morrison_Hotel_Toolkit Meta Boxes.
 *
 * @author   Lollum
 * @category Admin
 * @package  Morrison_Hotel_Toolkit/Admin/Meta Boxes
 * @version  1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'MH_TKT_Boxes' ) ) :

/**
 * MH_TKT_Boxes Class
 */
class MH_TKT_Boxes {

	/**
	 * Page meta boxes.
	 */
	private $page_meta_boxes = array();

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->list_page_meta_boxes();

		// Actions
		add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ), 30 );
		add_action( 'save_post', array( $this, 'save_meta_boxes' ), 10, 2 );

		// Filters
		add_filter( 'morrison_hotel_toolkit_meta_box_save_text', array( $this, 'sanitize_text' ) );
		add_filter( 'morrison_hotel_toolkit_meta_box_save_number', array( $this, 'sanitize_number' ) );
		add_filter( 'morrison_hotel_toolkit_meta_box_save_select', array( $this, 'sanitize_select' ) );
		add_filter( 'morrison_hotel_toolkit_meta_box_save_checkbox', array( $this, 'sanitize_checkbox' ) );
		add_filter( 'morrison_hotel_toolkit_meta_box_save_media', array( $this, 'sanitize_media' ) );

		$this->includes();
	}

	/**
	 * Include required files.
	 */
	private function includes() {
		include_once( 'metaboxes/class-meta-box-helper.php' );
		include_once( 'metaboxes/class-meta-box-pages.php' );
	}

	/**
	 * Page meta boxes list.
	 */
	private function list_page_meta_boxes() {
		$fields = array(
			'mh_hide_page_title'      => 'checkbox',
			'mh_center_page_title'    => 'checkbox',
			'mh_show_page_carousel'   => 'checkbox',
			'mh_show_booking_form'    => 'checkbox',
			'mh_page_carousel_images' => 'media',
		);

		$this->page_meta_boxes = $fields;
	}

	/**
	 * Add meta boxes
	 */
	public function add_meta_boxes() {
		// Pages
		add_meta_box( 'morrison-hotel-toolkit-page-settings', esc_html__( 'Page Settings', 'morrison-hotel-toolkit' ), 'MH_TKT_Meta_Box_Page_Settings::output', 'page', 'normal', 'high' );
	}

	/**
	 * Save meta boxes
	 */
	public function save_meta_boxes( $post_id, $post ) {

		// Check the nonce
		if ( empty( $_POST[ 'morrison_hotel_toolkit_meta_nonce' ] ) || ! wp_verify_nonce( $_POST[ 'morrison_hotel_toolkit_meta_nonce' ], 'morrison_hotel_toolkit_save_data' ) ) {
			return;
		}
		// Dont' save meta boxes for revisions or autosaves
		if ( defined( 'DOING_AUTOSAVE' ) || is_int( wp_is_post_revision( $post ) ) || is_int( wp_is_post_autosave( $post ) ) ) {
			return;
		}

		// Check user has permission to edit
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$fields = array();

		// Get page meta boxes
		if ( isset( $post->post_type ) && 'page' == $post->post_type ) {
			$fields = $this->page_meta_boxes;
		}

		foreach ( $fields as $field => $type ) {
			if ( ! empty( $_POST[ $field ] ) ) {
				$data = apply_filters( 'morrison_hotel_toolkit_meta_box_save_' . $type, $_POST[ $field ] );
				update_post_meta( $post_id, $field, $data );
			} else {
				delete_post_meta( $post_id, $field );
			}
		}
	}

	/**
	 * Sanitize text input
	 */
	public function sanitize_text( $data ) {
		return sanitize_text_field( $data );
	}

	/**
	 * Sanitize number
	 */
	public function sanitize_number( $number ) {
		return absint( $number );
	}

	/**
	 * Sanitize select input
	 */
	public function sanitize_select( $data ) {
		return sanitize_key( $data );
	}

	/**
	 * Sanitize checkbox input
	 */
	public function sanitize_checkbox( $data ) {
		return filter_var( $data, FILTER_SANITIZE_NUMBER_INT );
	}

	/**
	 * Sanitize media input
	 */
	public function sanitize_media( $data ) {
		$attachment_ids = $data ? array_filter( explode( ',', sanitize_text_field( $data ) ) ) : array();
		return implode( ',', $attachment_ids );
	}

}

endif;

new MH_TKT_Boxes();
