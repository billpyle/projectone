<?php
/**
 * Page Settings.
 *
 * @author   Lollum
 * @category Admin
 * @package  Morrison_Hotel_Toolkit/Admin/Meta Boxes
 * @version  1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'MH_TKT_Meta_Box_Page_Settings' ) ) :

/**
 * MH_TKT_Meta_Box_Page_Settings Class
 */
class MH_TKT_Meta_Box_Page_Settings {

	/**
	 * Output the metabox
	 */
	public static function output( $post ) {
		$thepostid = empty( $thepostid ) ? $post->ID : $thepostid;
		wp_nonce_field( 'morrison_hotel_toolkit_save_data', 'morrison_hotel_toolkit_meta_nonce' );

		?>

		<div class="morrison-hotel-toolkit-page-settings">

			<?php
			MH_TKT_Meta_Box_Helper::checkbox_input( array( 'id' => 'mh_center_page_title', 'label' => esc_html__( 'Center page title?', 'morrison-hotel-toolkit' ) ) );

			MH_TKT_Meta_Box_Helper::checkbox_input( array( 'id' => 'mh_hide_page_title', 'label' => esc_html__( 'Hide page title?', 'morrison-hotel-toolkit' ) ) );

			MH_TKT_Meta_Box_Helper::checkbox_input( array( 'id' => 'mh_show_page_carousel', 'label' => esc_html__( 'Show page carousel?', 'morrison-hotel-toolkit' ) ) );

			MH_TKT_Meta_Box_Helper::media_input();

			MH_TKT_Meta_Box_Helper::checkbox_input( array( 'id' => 'mh_show_booking_form', 'label' => esc_html__( 'Show Booking Form?', 'morrison-hotel-toolkit' ) ) );
			?>

		</div><!-- .morrison-hotel-toolkit-page-settings -->

		<?php

	}

}

endif;
