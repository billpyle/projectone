<?php
/**
 * Core Functions.
 *
 * @author   Lollum
 * @category Core
 * @package  Morrison_Hotel_Toolkit/Functions
 * @version  1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Enqueue frontend scripts and styles.
 */
function morrison_hotel_toolkit_register_scripts() {
	if ( ! is_home() && ! is_page() ) {
		return;
	}

	wp_register_script( 'mh_tkt-owl-carousel', MH_TKT_PLUGIN_URL . 'assets/js/lib/owl.carousel.min.js', array( 'jquery' ), '2.0.0', true );

	if ( is_home() ) {
		global $wp_query;

		$page_id = $wp_query->get_queried_object_id();

	} else {
		global $post;

		$page_id = $post->ID;
	}

	if ( get_post_meta( $page_id, 'mh_show_page_carousel', true ) ) {
		wp_enqueue_script( 'mh_tkt-owl-carousel' );
	}
}
add_action( 'wp_enqueue_scripts', 'morrison_hotel_toolkit_register_scripts' );
