(function($) {

	'use strict';

	var MH_TKT_Page_Settings = {
		init: function() {
			this.show_meta();
			this.add_images();
			this.sort_images();
			this.delete_images();
		},

		show_meta: function() {
			var carouselCheckbox = $('#mh_show_page_carousel');
			var carouselContainer = $('#page-carousel-images-container').closest('.form-field');

			carouselContainer.hide();

			if (carouselCheckbox.prop('checked')) {
				carouselContainer.show();
			}

			carouselCheckbox.click(function () {
				carouselContainer.toggle(this.checked);
			});
		},

		add_images: function() {
			var add_images_button = $('#add-page-carousel-images');
			var page_carousel_frame;
			var page_carousel_ids  = $('#page-carousel-images');
			var page_carousel_images = $('#page-carousel-images-container').find('ul.carousel-images');

			add_images_button.on('click', function(e) {
				e.preventDefault();

				var _this = $(this);

				// If the media frame already exists, reopen it.
				if (page_carousel_frame) {
					page_carousel_frame.open();
					return;
				}

				// Create the media frame.
				page_carousel_frame = wp.media.frames.page_carousel = wp.media({
					// Set the title of the modal.
					title: _this.data('choose'),
					button: {
						text: _this.data('update')
					},
					states: [
						new wp.media.controller.Library({
							title: _this.data('choose'),
							filterable: 'all',
							multiple: true
						})
					]
				});

				// When an image is selected, run a callback.
				page_carousel_frame.on('select', function() {
					var selection      = page_carousel_frame.state().get('selection');
					var attachment_ids = page_carousel_ids.val();

					selection.map(function(attachment) {
						attachment = attachment.toJSON();

						if (attachment.id) {
							attachment_ids   = attachment_ids ? attachment_ids + ',' + attachment.id : attachment.id;
							var attachment_image = attachment.sizes && attachment.sizes.thumbnail ? attachment.sizes.thumbnail.url : attachment.url;

							page_carousel_images.append('<li class="image" data-attachment_id="' + attachment.id + '"><img src="' + attachment_image + '" /><a href="#" class="delete" title="' + _this.data('delete') + '">' + _this.data('text') + '</a></li>');
						}
					});

					page_carousel_ids.val(attachment_ids);
				});

				// Finally, open the modal.
				page_carousel_frame.open();
			});

		},

		sort_images: function() {
			var page_carousel_images      = $('#page-carousel-images-container').find('ul.carousel-images');
			var page_carousel_ids = $('#page-carousel-images');

			page_carousel_images.sortable({
				items: 'li.image',
				cursor: 'move',
				forcePlaceholderSize: true,
				forceHelperSize: false,
				helper: 'clone',
				opacity: 0.65,
				placeholder: 'mh-image-sortable-placeholder',
				start: function(event, ui) {
					var styles = {
						backgroundColor : '#f6f6f6'
					};

					ui.item.css(styles);
				},
				stop: function(event, ui) {
					ui.item.removeAttr('style');
				},
				update: function() {
					var attachment_ids = '';

					$('#page-carousel-images-container').find('ul li.image').css('cursor', 'default').each(function() {
						var attachment_id = jQuery(this).attr('data-attachment_id');
						attachment_ids    = attachment_ids + attachment_id + ',';
					});

					page_carousel_ids.val(attachment_ids);
				}
			});
		},

		delete_images: function() {
			var page_carousel_ids = $('#page-carousel-images');
			var page_carousel_images      = $('#page-carousel-images-container');

			page_carousel_images.on('click', 'a.delete', function(e) {
				e.preventDefault();

				$(this).closest('li.image').remove();

				var attachment_ids = '';

				page_carousel_images.find('ul li.image').css('cursor', 'default').each(function() {
					var attachment_id = jQuery(this).attr('data-attachment_id');
					attachment_ids    = attachment_ids + attachment_id + ',';
				});

				page_carousel_ids.val(attachment_ids);
			});
		}
	};

	$(document).ready(function() {
		MH_TKT_Page_Settings.init();
	});
})(jQuery);
