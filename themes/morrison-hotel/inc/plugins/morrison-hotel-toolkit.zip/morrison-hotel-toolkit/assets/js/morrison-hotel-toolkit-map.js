(function($) {

	'use strict';

	/* global google, jQuery */
	/* jshint unused: false */

	$('.map-canvas-wrapper').each(function() {
		var el = $(this);
		var lat = el.data('lat');
		var lng = el.data('lng');
		var hue = el.data('hue');
		var z = el.data('zoom');
		var m = el.data('marker');
		var mapCanvas = el.children().get(0);
		var coordinates = new google.maps.LatLng(lat, lng);
		var mapOptions = {
			zoom: z,
			center: coordinates,
			scrollwheel: false,
			mapTypeId: google.maps.MapTypeId.ROADMAP,
			mapTypeControl: false
		};
		var map = new google.maps.Map(mapCanvas, mapOptions);

		if (m === 'marker-yes') {
			var marker = new google.maps.Marker({
				position: coordinates,
				map: map
	    	});
		}

		var styles = [{
				stylers: [
					{ saturation: -10 },
					{ hue: '#' + hue },
				]
			}
		];

		map.setOptions({styles: styles});
	});

})(jQuery);
