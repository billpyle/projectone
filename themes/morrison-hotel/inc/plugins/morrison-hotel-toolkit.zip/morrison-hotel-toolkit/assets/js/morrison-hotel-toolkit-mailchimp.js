(function($) {
	$(document).ready(function() {
		'use strict';
		/* global morrison_hotel_process_form_vars, jQuery */

		$('.morrison-hotel-newsletter-button').on('click', function(e) {
			e.preventDefault();

			var el = $(this);
			var form = el.parent('form');
			var display_name = form.data('name');
			var confirm = form.data('confirm');
			var list_id = form.find('.morrison-hotel-newsletter-list-id').val();
			var first_name = form.find('.morrison-hotel-newsletter-first-name').val();
			var last_name = form.find('.morrison-hotel-newsletter-last-name').val();
			var email = form.find('.morrison-hotel-newsletter-email').val();
			var response_message_el = form.parent('.morrison-hotel-newsletter').find('.morrison-hotel-newsletter-response');
			var btn_orig_text = el.val();
			var btn_wait_text = el.data('wait-text');

			el.val(btn_wait_text);
			response_message_el.find('.morrison-hotel-newsletter-message').remove();

			var post_data = {
				action: 'morrison_hotel_mailchimp_form',
				morrison_hotel_m_display_name: display_name,
				morrison_hotel_m_confirm: confirm,
				morrison_hotel_m_list_id: list_id,
				morrison_hotel_m_first_name: first_name,
				morrison_hotel_m_last_name: last_name,
				morrison_hotel_m_email: email,
				morrison_hotel_m_nonce: morrison_hotel_process_form_vars.nonce
			};

			$.post(morrison_hotel_process_form_vars.ajaxurl, post_data, function(response) {
				el.val(btn_orig_text);
				response_message_el.append(response);
			});
		});
	});
})(jQuery);
