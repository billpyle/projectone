=== Morrison Hotel Toolkit ===
Requires at least: 4.1
Tested up to: 4.4
License: GPLv3

Extra functionality for the Morrison Hotel theme.

== Description ==

The Morrison Hotel Toolkit plugin extends the functionality of the Morrison Hotel theme by adding custom meta boxes, shortcodes and widgets. The plugin is required by the Morrison Hotel theme because it will extend the theme to function as you see in the demo.

== Installation ==

This plugin can be installed directly from your site.

When you activate the Morrison Hotel theme you see a warning asking you to install the required plugins. Just click on the 'Begin installing plugins' button.

== Frequently Asked Questions ==

= Can I use this plugin with other themes? =

The Morrison Hotel Toolkit plugin was developed to extend the functionality of the Morrison Hotel theme specifically. It is not a plugin meant for use with other themes.

== Credits ==

This program includes some awesome JS plugins like:

- Flexslider by WooThemes (http://flexslider.woothemes.com/)
- Owl Carousel by Bartosz Wojciechowski (http://www.owlcarousel.owlgraphic.com/)

Thank you very much guys :)
