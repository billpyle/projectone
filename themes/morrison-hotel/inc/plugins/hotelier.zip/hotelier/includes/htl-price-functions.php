<?php
/**
 * Hotelier Price Functions.
 *
 * @author   Lollum
 * @category Core
 * @package  Hotelier/Functions
 * @version  0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Return the thousand separator for prices
 * @return string
 */
function htl_get_price_thousand_separator() {
	$separator = stripslashes( htl_get_option( 'thousands_separator', ',' ) );
	return $separator;
}

/**
 * Return the decimal separator for prices
 * @return string
 */
function htl_get_price_decimal_separator() {
	$separator = stripslashes( htl_get_option( 'decimal_separator', '.' ) );
	return $separator ? $separator : '.';
}

/**
 * Return the number of decimals after the decimal point.
 * @return int
 */
function htl_get_price_decimals() {
	return absint( htl_get_option( 'price_num_decimals', 2 ) );
}

/**
 * Get full list of currency codes.
 */
function htl_get_currencies() {
	$currencies = array(
		'USD'  => esc_html__( 'US Dollars (&#36;)', 'hotelier' ),
		'EUR'  => esc_html__( 'Euros (&euro;)', 'hotelier' ),
		'GBP'  => esc_html__( 'Pounds Sterling (&pound;)', 'hotelier' ),
		'AUD'  => esc_html__( 'Australian Dollars (&#36;)', 'hotelier' ),
		'BRL'  => esc_html__( 'Brazilian Real (R&#36;)', 'hotelier' ),
		'CAD'  => esc_html__( 'Canadian Dollars (&#36;)', 'hotelier' ),
		'CZK'  => esc_html__( 'Czech Koruna', 'hotelier' ),
		'DKK'  => esc_html__( 'Danish Krone', 'hotelier' ),
		'HKD'  => esc_html__( 'Hong Kong Dollar (&#36;)', 'hotelier' ),
		'HUF'  => esc_html__( 'Hungarian Forint', 'hotelier' ),
		'ILS'  => esc_html__( 'Israeli Shekel (&#8362;)', 'hotelier' ),
		'JPY'  => esc_html__( 'Japanese Yen (&yen;)', 'hotelier' ),
		'MYR'  => esc_html__( 'Malaysian Ringgits', 'hotelier' ),
		'MXN'  => esc_html__( 'Mexican Peso (&#36;)', 'hotelier' ),
		'NZD'  => esc_html__( 'New Zealand Dollar (&#36;)', 'hotelier' ),
		'NOK'  => esc_html__( 'Norwegian Krone', 'hotelier' ),
		'PHP'  => esc_html__( 'Philippine Pesos', 'hotelier' ),
		'PLN'  => esc_html__( 'Polish Zloty', 'hotelier' ),
		'SGD'  => esc_html__( 'Singapore Dollar (&#36;)', 'hotelier' ),
		'SEK'  => esc_html__( 'Swedish Krona', 'hotelier' ),
		'CHF'  => esc_html__( 'Swiss Franc', 'hotelier' ),
		'TWD'  => esc_html__( 'Taiwan New Dollars', 'hotelier' ),
		'THB'  => esc_html__( 'Thai Baht (&#3647;)', 'hotelier' ),
		'INR'  => esc_html__( 'Indian Rupee (&#8377;)', 'hotelier' ),
		'TRY'  => esc_html__( 'Turkish Lira (&#8378;)', 'hotelier' ),
		'RUB'  => esc_html__( 'Russian Rubles', 'hotelier' )
	);

	return apply_filters( 'hotelier_currencies', $currencies );
}

/**
 * Get Base Currency Code.
 * @return string
 */
function htl_get_currency() {
	return apply_filters( 'hotelier_currency', htl_get_option( 'currency', 'USD' ) );
}

/**
 * Get Currency symbol.
 * @param string $currency (default: '')
 * @return string
 */
function htl_get_currency_symbol( $currency = '' ) {
	if ( ! $currency ) {
		$currency = htl_get_currency();
	}

	switch ( $currency ) {
		case 'AUD' :
		case 'CAD' :
		case 'HKD' :
		case 'MXN' :
		case 'NZD' :
		case 'SGD' :
		case 'USD' :
			$currency_symbol = '&#36;';
			break;
		case 'BRL' :
			$currency_symbol = '&#82;&#36;';
			break;
		case 'CHF' :
			$currency_symbol = '&#67;&#72;&#70;';
			break;
		case 'JPY' :
			$currency_symbol = '&yen;';
			break;
		case 'CZK' :
			$currency_symbol = '&#75;&#269;';
			break;
		case 'DKK' :
			$currency_symbol = 'DKK';
			break;
		case 'EUR' :
			$currency_symbol = '&euro;';
			break;
		case 'GBP' :
			$currency_symbol = '&pound;';
			break;
		case 'HUF' :
			$currency_symbol = '&#70;&#116;';
			break;
		case 'ILS' :
			$currency_symbol = '&#8362;';
			break;
		case 'INR' :
			$currency_symbol = 'Rs.';
			break;
		case 'MYR' :
			$currency_symbol = '&#82;&#77;';
			break;
		case 'NOK' :
			$currency_symbol = '&#107;&#114;';
			break;
		case 'PHP' :
			$currency_symbol = '&#8369;';
			break;
		case 'PLN' :
			$currency_symbol = '&#122;&#322;';
			break;
		case 'RUB' :
			$currency_symbol = '&#1088;&#1091;&#1073;.';
			break;
		case 'SEK' :
			$currency_symbol = '&#107;&#114;';
			break;
		case 'THB' :
			$currency_symbol = '&#3647;';
			break;
		case 'TRY' :
			$currency_symbol = '&#8378;';
			break;
		case 'TWD' :
			$currency_symbol = '&#78;&#84;&#36;';
			break;
		default :
			$currency_symbol = '';
			break;
	}

	return apply_filters( 'hotelier_currency_symbol', $currency_symbol, $currency );
}


/**
 * Format the price with a currency symbol.
 *
 * @param float $price
 * @param string $currency
 * @return string
 */
function htl_price( $price, $currency = '' ) {
	$thousands_sep = htl_get_price_thousand_separator();
	$decimal_sep   = htl_get_price_decimal_separator();
	$decimals      = htl_get_price_decimals();
	$position      = htl_get_option( 'currency_position', 'before' );
	$price         = number_format( (double) $price, $decimals, $decimal_sep, $thousands_sep );
	$price         = ( $position == 'before' ) ? htl_get_currency_symbol( $currency ) . $price : $price . htl_get_currency_symbol( $currency );
	$return        = '<span class="amount">' . $price . '</span>';

	return apply_filters( 'hotelier_price', $return, $price );
}

/**
 * Count cents in prices (prices are stored as integers).
 *
 * @param int $amount
 * @return float
 */
function htl_convert_to_cents( $amount ) {
	$amount = $amount / 100;

	return apply_filters( 'hotelier_convert_to_cents', $amount );
}

/**
 * Calculates the deposit with a currency symbol.
 *
 * @param int $price
 * @param int $deposit
 * @param string $currency
 * @return string
 */
function htl_calculate_deposit( $price, $deposit, $currency = '' ) {
	$price = $price / 100;
	$price = ( $price * $deposit ) / 100;

	$price = htl_price( $price, $currency );

	return apply_filters( 'hotelier_calculate_deposit', $price );
}
