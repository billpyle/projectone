<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Booking Widget.
 *
 * Displays current rooms selected and booking details.
 *
 * @author   Lollum
 * @category Widgets
 * @package  Hotelier/Widgets
 * @version  0.9.0
 * @extends  HTL_Widget
 */

class HTL_Widget_Booking extends HTL_Widget {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->widget_cssclass    = 'hotelier widget-hotelier widget-hotelier-booking';
		$this->widget_description = esc_html__( 'Displays current rooms selected and booking details. Visible only in the "listing" and "booking" pages.', 'hotelier' );
		$this->widget_id          = 'hotelier-widget-booking';
		$this->widget_name        = esc_html__( 'Hotelier Booking', 'hotelier' );
		$this->settings           = array(
			'title'  => array(
				'type'  => 'text',
				'std'   => esc_html__( 'Your Stay', 'hotelier' ),
				'label' => esc_html__( 'Title', 'hotelier' )
			)
		);

		parent::__construct();
	}

	/**
	 * widget function.
	 *
	 * @see WP_Widget
	 *
	 * @param array $args
	 * @param array $instance
	 */
	public function widget( $args, $instance ) {
		if ( ( ! is_listing() && ! is_booking() ) || is_reservation_received_page() || is_pay_reservation_page() ) {
			return;
		}

		// Arrival date must be "XX" days from current date (default 0).
		$from     = htl_get_option( 'booking_arrival_date', 0 );
		$to       = $from + 1;

		$checkin  = ! is_null( HTL()->session->get( 'checkin' ) ) ? HTL()->session->get( 'checkin' ) :  date( 'Y-m-d', strtotime( "+$from days" ) );
		$checkout = ! is_null( HTL()->session->get( 'checkout' ) ) ? HTL()->session->get( 'checkout' ) : date( 'Y-m-d', strtotime( "+$to days" ) );

		$this->widget_start( $args, $instance );

		?>

		<div class="widget-booking-content">

			<?php if ( is_booking() ) : ?>
				<p><a href="<?php echo esc_url( HTL()->cart->get_room_list_form_url() ); ?>" class="change-cart"><?php esc_html_e( 'Modify', 'hotelier' ); ?></a></p>
			<?php endif; ?>

			<div class="dates">
				<div class="checkin">

					<span class="date-label"><?php esc_html_e( 'Check-in', 'hotelier' ); ?></span>

					<div class="date-block">
						<span class="month-year"><?php echo date_i18n( 'M Y', strtotime( $checkin ) ); ?></span>
						<span class="day"><?php echo date_i18n( 'd', strtotime( $checkin ) ); ?></span>
						<span class="day-name"><?php echo date_i18n( 'D', strtotime( $checkin ) ); ?></span>
					</div>

				</div>

				<div class="checkout">

					<span class="date-label"><?php esc_html_e( 'Check-out', 'hotelier' ); ?></span>

					<div class="date-block">
						<span class="month-year"><?php echo date_i18n( 'M Y', strtotime( $checkout ) ); ?></span>
						<span class="day"><?php echo date_i18n( 'd', strtotime( $checkout ) ); ?></span>
						<span class="day-name"><?php echo date_i18n( 'D', strtotime( $checkout ) ); ?></span>
					</div>

				</div>
			</div>

			<?php if ( HTL()->session->get( 'cart' ) ) : ?>

				<ul class="room-list-widget">

				<?php foreach ( HTL()->cart->get_cart() as $cart_item_key => $cart_item ) :
					$_room    = $cart_item[ 'data' ];
					$_room_id = $cart_item[ 'room_id' ];

					if ( $_room && $_room->exists() && $cart_item[ 'quantity' ] > 0 ) : ?>

						<li>
							<a href="<?php echo esc_url( get_permalink( $_room_id ) ); ?>"><?php echo esc_html( $_room->get_title() ); ?> <?php echo $cart_item[ 'quantity' ] > 1 ? '&times; ' . esc_html( $cart_item[ 'quantity' ] ) : ''; ?></a>
							<?php if ( $cart_item[ 'rate_name' ] ) : ?>
								<small><?php printf( esc_html__( 'Rate: %s', 'hotelier' ), htl_get_formatted_room_rate( $cart_item[ 'rate_name' ] ) ); ?></small>
							<?php endif; ?>
						</li>

					<?php endif;
				endforeach; ?>

				</ul>

				<span class="total"><strong><?php esc_html_e( 'Total', 'hotelier' ); ?></strong><?php echo htl_cart_formatted_total(); ?></span>

			<?php endif; ?>

		</div>

		<?php
		$this->widget_end( $args );
	}
}
