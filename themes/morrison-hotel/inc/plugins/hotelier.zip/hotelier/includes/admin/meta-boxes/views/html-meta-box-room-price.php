<?php
/**
 * Shows the room price
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>

<div class="room-price-panel">

	<?php

	// room price

	$price_type = array(
		'global' => esc_html__( 'Global', 'hotelier' ),
		'per_day' => esc_html__( 'Price per day', 'hotelier' )
	);

	HTL_Meta_Boxes_Helper::select_input( array( 'id' => '_price_type', 'label' => esc_html__( 'Price:', 'hotelier' ), 'class' => 'room-price', 'options' => $price_type ) );

	?>

	<div class="price-panel price-panel-global">

		<?php

		HTL_Meta_Boxes_Helper::text_input( array( 'id' => '_regular_price', 'label' => esc_html__( 'Regular Price:', 'hotelier' ), 'wrapper_class' => 'price', 'data_type' => 'price', 'placeholder' => self::get_price_placeholder(), 'desc_tip' => 'true', 'description' => esc_html__( 'Same price for all days of the week.', 'hotelier' ) ) );

		HTL_Meta_Boxes_Helper::text_input( array( 'id' => '_sale_price', 'label' => esc_html__( 'Sale Price:', 'hotelier' ), 'wrapper_class' => 'price', 'data_type' => 'price', 'placeholder' => self::get_price_placeholder(), 'desc_tip' => 'true', 'description' => esc_html__( 'Same price for all days of the week.', 'hotelier' ) ) );

		?>

	</div><!-- .global-price -->

	<div class="price-panel price-panel-per_day">

		<?php

		HTL_Meta_Boxes_Helper::price_per_day( array( 'id' => '_regular_price_day', 'label' => esc_html__( 'Regular Price:', 'hotelier' ), 'desc_tip' => 'true', 'description' => esc_html__( 'The regular price of the room per day.', 'hotelier' ) ) );

		HTL_Meta_Boxes_Helper::price_per_day( array( 'id' => '_sale_price_day', 'label' => esc_html__( 'Sale Price:', 'hotelier' ), 'desc_tip' => 'true', 'description' => esc_html__( 'The sale price of the room per day.', 'hotelier' ) ) );

		?>

	</div><!-- .price-per-day -->

</div><!-- .room-price-panel -->
