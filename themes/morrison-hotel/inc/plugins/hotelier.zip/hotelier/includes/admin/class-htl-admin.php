<?php
/**
 * Hotelier Admin
 *
 * @author   Lollum
 * @category Admin
 * @package  Hotelier/Admin
 * @version  0.9.0
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'HTL_Admin' ) ) :

/**
 * HTL_Admin Class
 */
class HTL_Admin {
	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'includes' ) );
	}

	/**
	 * Include any classes we need within admin.
	 */
	public function includes() {
		include_once( 'settings/class-htl-admin-settings.php' );
		include_once( 'class-htl-admin-functions.php' );
		include_once( 'meta-boxes/class-htl-admin-meta-boxes-helper.php' );
		include_once( 'class-htl-admin-post-types.php' );
		include_once( 'class-htl-admin-menus.php' );
		include_once( 'class-htl-admin-scripts.php' );
		include_once( 'class-htl-admin-notices.php' );
		include_once( 'new-reservation/class-htl-admin-new-reservation.php' );
		include_once( 'settings/class-htl-admin-logs.php' );
	}
}

endif;

return new HTL_Admin();
