<?php
/**
 * Admin View: New reservation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$years  = range( date( 'Y' ), date( 'Y' ) + 10 );
$months = range( 1, 12 );
$days   = range( 1, 31 );

?>

<div class="wrap hotelier">
	<?php
	// Check if we have at least one room
	$args = array(
		'post_type'           => 'room',
		'post_status'         => 'publish',
		'ignore_sticky_posts' => 1,
		'posts_per_page'      => -1,
		'orderby'             => 'title',
		'order'               => 'ASC',
		'meta_query'          => array(
			array(
				'key'     => '_stock_rooms',
				'value'   => 0,
				'compare' => '>',
			),
		),
	);

	$rooms = new WP_Query( $args );

	if ( $rooms->have_posts() ) : ?>

		<h1><?php esc_html_e( 'Add New Reservation', 'hotelier' ); ?></h1>

		<form method="post" class="add-new-reservation-form">
			<table class="form-table">
				<tbody>
					<tr>
						<th scope="row"><?php esc_html_e( 'Select room:', 'hotelier' ); ?></th>
						<td>
							<div class="add-new-room-row" data-key="0">
								<?php echo htl_get_list_of_rooms_html( 'room[0]' ); ?>
								<input type="number" name="room_qty[0]" value="1">
								<button type="button" class="button remove-room" disabled><?php esc_html_e( 'Remove room', 'hotelier' ); ?></button>
							</div>
							<button type="button" class="button button-primary add-new-room"><?php esc_html_e( 'Add another room', 'hotelier' ); ?></button>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Check-in:', 'hotelier' ); ?></th>
						<td>
							<select name="from[y]">
								<?php foreach ( $years as $year ) : ?>
									<option value="<?php echo esc_attr( $year ) ?>"><?php echo esc_html( $year ) ?></option>
								<?php endforeach; ?>
							</select>
							<select name="from[m]">
								<?php foreach ( $months as $month ) : ?>
									<option value="<?php echo esc_attr( sprintf('%02d', $month) ) ?>" <?php selected( date( 'n' ), $month ); ?>><?php echo esc_html( sprintf('%02d', $month) ) ?></option>
								<?php endforeach; ?>
							</select>
							<select name="from[d]">
								<?php foreach ( $days as $day ) : ?>
									<option value="<?php echo esc_attr( sprintf('%02d', $day) ) ?>" <?php selected( date( 'j' ), $day ); ?>><?php echo esc_html( sprintf('%02d', $day) ) ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Check-out:', 'hotelier' ); ?></th>
						<td>
							<select name="to[y]">
								<?php foreach ( $years as $year ) : ?>
									<option value="<?php echo esc_attr( $year ) ?>"><?php echo esc_html( $year ) ?></option>
								<?php endforeach; ?>
							</select>
							<select name="to[m]">
								<?php foreach ( $months as $month ) : ?>
									<option value="<?php echo esc_attr( sprintf('%02d', $month) ) ?>" <?php selected( date( 'n' ), $month ); ?>><?php echo esc_html( sprintf('%02d', $month) ) ?></option>
								<?php endforeach; ?>
							</select>
							<select name="to[d]">
								<?php foreach ( $days as $day ) : ?>
									<option value="<?php echo esc_attr( sprintf('%02d', $day) ) ?>" <?php selected( date( 'j' ) + 1, $day ); ?>><?php echo esc_html( sprintf('%02d', $day) ) ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row"><strong><?php esc_html_e( 'Guest Details', 'hotelier' ); ?></strong></th>
						<td><hr></td>
					</tr>
					<?php foreach ( HTL_Meta_Box_Reservation_Data::get_guest_details_fields() as $key => $field ) :
						$type     = isset( $field[ 'type' ] ) ? $field[ 'type' ] : 'text';
						$required = isset( $field[ 'required' ] ) ? ' * ' : '';
						?>
						<tr>
							<th scope="row"><?php echo esc_html( $field[ 'label' ] ) . $required ; ?></th>
							<td><input type="<?php echo esc_attr( $type ); ?>" name="<?php echo esc_attr( $key ); ?>"></td>
						</tr>
					<?php endforeach ?>
				</tbody>
			</table>

			<p class="submit">
				<input type="submit" name="hotelier_admin_add_new_reservation" class="button button-primary add-new-reservation" value="<?php esc_attr_e( 'Save Reservation', 'hotelier' ); ?>">
				<?php wp_nonce_field( 'hotelier_admin_process_new_reservation' ); ?>
			</p>
		</form>

	<?php else : ?>

		<div class="error"><p><?php esc_html_e( 'In order to create a reservation, you need to have at least one room.', 'hotelier' ); ?></p></div>

		<p><?php printf( wp_kses( __( 'Create a new room <a href="%s">here</a>.', 'hotelier' ), array( 'a' => array( 'href' => array() ) ) ), 'post-new.php?post_type=room' ); ?></p>

	<?php endif; ?>
</div>
