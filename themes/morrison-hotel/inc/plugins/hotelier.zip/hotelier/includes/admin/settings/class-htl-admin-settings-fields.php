<?php
/**
 * Creates and validates the settings fields.
 *
 * @author   Lollum
 * @category Admin
 * @package  Hotelier/Admin
 * @version  0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'HTL_Admin_Settings_Fields' ) ) :

/**
 * HTL_Admin_Settings_Fields Class
 */
class HTL_Admin_Settings_Fields {

	/**
    * Holds the values to be used in the fields callbacks
    */
   private $options = array();

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->options = get_option( 'hotelier_settings' );

		// Fields callback (HTML)
		add_filter( 'hotelier_settings_header_callback', array( $this, 'print_header' ), 10, 2 );
		add_filter( 'hotelier_settings_description_callback', array( $this, 'print_description' ), 10, 2 );
		add_filter( 'hotelier_settings_text_callback', array( $this, 'print_text' ), 10, 2 );
		add_filter( 'hotelier_settings_email_callback', array( $this, 'print_email' ), 10, 2 );
		add_filter( 'hotelier_settings_upload_callback', array( $this, 'print_upload' ), 10, 2 );
		add_filter( 'hotelier_settings_number_callback', array( $this, 'print_number' ), 10, 2 );
		add_filter( 'hotelier_settings_booking_hold_minutes_callback', array( $this, 'print_booking_hold_minutes' ), 10, 2 );
		add_filter( 'hotelier_settings_select_callback', array( $this, 'print_select' ), 10, 2 );
		add_filter( 'hotelier_settings_checkbox_callback', array( $this, 'print_checkbox' ), 10, 2 );
		add_filter( 'hotelier_settings_radio_callback', array( $this, 'print_radio' ), 10, 2 );
		add_filter( 'hotelier_settings_button_callback', array( $this, 'print_button' ), 10, 2 );
		add_filter( 'hotelier_settings_card_icons_callback', array( $this, 'print_card_icons' ), 10, 2 );
		add_filter( 'hotelier_settings_gateways_callback', array( $this, 'print_gateways' ), 10, 2 );
		add_filter( 'hotelier_settings_gateway_select_callback', array( $this, 'print_gateway_select' ), 10, 2 );
		add_filter( 'hotelier_settings_image_size_callback', array( $this, 'print_image_size' ), 10, 2 );
		add_filter( 'hotelier_settings_from_to_callback', array( $this, 'print_from_to' ), 10, 2 );
		add_filter( 'hotelier_settings_info_callback', array( $this, 'print_info' ), 10, 2 );

		// Fields validation
		add_filter( 'hotelier_settings_sanitize_text', array( $this, 'sanitize_text' ) );
		add_filter( 'hotelier_settings_sanitize_email', array( $this, 'sanitize_email' ) );
		add_filter( 'hotelier_settings_sanitize_upload', array( $this, 'sanitize_upload' ) );
		add_filter( 'hotelier_settings_sanitize_number', array( $this, 'sanitize_number' ) );
		add_filter( 'hotelier_settings_sanitize_select', array( $this, 'sanitize_select' ), 10, 2 );
		add_filter( 'hotelier_settings_sanitize_booking_hold_minutes', array( $this, 'sanitize_booking_hold_minutes' ) );
		add_filter( 'hotelier_settings_sanitize_image_size', array( $this, 'sanitize_image_size' ) );

		// Actions
		add_action( 'hotelier_settings_hook_install_pages', array( $this, 'install_pages' ) );
		add_action( 'hotelier_settings_hook_send_test_email', array( $this, 'send_test_email' ) );
		add_action( 'hotelier_settings_hook_clear_sessions', array( $this, 'clear_sessions' ) );
		add_action( 'hotelier_settings_hook_delete_completed_bookings', array( $this, 'delete_completed_bookings' ) );
		add_action( 'hotelier_settings_info_server_info', array( $this, 'print_server_info' ) );
		add_action( 'hotelier_settings_info_php_version', array( $this, 'print_php_version' ) );
		add_action( 'hotelier_settings_info_wp_memory_limit', array( $this, 'print_wp_memory_limit' ) );
		add_action( 'hotelier_settings_info_php_post_max_size', array( $this, 'print_php_post_max_size' ) );
		add_action( 'hotelier_settings_info_php_post_max_upload_size', array( $this, 'print_php_post_max_upload_size' ) );
		add_action( 'hotelier_settings_info_php_time_limit', array( $this, 'print_php_time_limit' ) );
		add_action( 'hotelier_settings_info_php_max_input_vars', array( $this, 'print_php_max_input_vars' ) );
		add_action( 'hotelier_settings_info_fsockopen_cURL', array( $this, 'print_fsockopen_cURL' ) );
		add_action( 'hotelier_settings_info_domdocument', array( $this, 'print_domdocument' ) );
		add_action( 'hotelier_settings_info_log_directory_writable', array( $this, 'print_log_directory_writable' ) );
	}

	/**
	 * Print header section
	 */
	public function print_header( $html, $args ) {
		echo '<hr/>';
	}

	/**
	 * Print description section
	 */
	public function print_description( $html, $args ) {
		echo '<p class="section-description">' . wp_kses_post( $args[ 'desc' ] ) . '</p>';
	}

	/**
	 * Print text input
	 */
	public function print_text( $html, $args ) {
		if ( isset( $this->options[ $args[ 'id' ] ] ) ) {
			$value = $this->options[ $args[ 'id' ] ];
		} else {
			$value = isset( $args[ 'std' ] ) ? $args[ 'std' ] : '';
		}

		$placeholder = isset( $args[ 'placeholder' ] ) ? $args[ 'placeholder' ] : '';

		$size     = ( isset( $args[ 'size' ] ) && ! is_null( $args[ 'size' ] ) ) ? $args[ 'size' ] : 'regular';
		$html     = '<input type="text" class="' . esc_attr( $size ) . '-text" id="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . ']" name="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . ']" value="' . esc_attr( $value ) . '" placeholder="' . esc_attr( $placeholder ) . '" />';
		$html    .= '<label for="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . ']"> '  . wp_kses_post( $args[ 'desc' ] ) . '</label>';

		echo $html;
	}

	/**
	 * Print email input
	 */
	public function print_email( $html, $args ) {
		if ( isset( $this->options[ $args[ 'id' ] ] ) ) {
			$value = $this->options[ $args[ 'id' ] ];
		} else {
			$value = isset( $args[ 'std' ] ) ? $args[ 'std' ] : '';
		}

		$placeholder = isset( $args[ 'placeholder' ] ) ? $args[ 'placeholder' ] : '';

		$size     = ( isset( $args[ 'size' ] ) && ! is_null( $args[ 'size' ] ) ) ? $args[ 'size' ] : 'regular';
		$html     = '<input type="email" class="' . esc_attr( $size ) . '-text" id="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . ']" name="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . ']" value="' . esc_attr( $value ) . '" placeholder="' . esc_attr( $placeholder ) . '" />';
		$html    .= '<label for="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . ']"> '  . wp_kses_post( $args[ 'desc' ] ) . '</label>';

		echo $html;
	}

	/**
	 * Print upload input
	 */
	public function print_upload( $html, $args ) {
		if ( isset( $this->options[ $args[ 'id' ] ] ) ) {
			$value = $this->options[ $args[ 'id' ] ];
		} else {
			$value = isset( $args[ 'std' ] ) ? $args[ 'std' ] : '';
		}

		$placeholder = isset( $args[ 'placeholder' ] ) ? $args[ 'placeholder' ] : '';

		$size     = ( isset( $args[ 'size' ] ) && ! is_null( $args[ 'size' ] ) ) ? $args[ 'size' ] : 'regular';
		$html     = '<input type="text" class="' . esc_attr( $size ) . '-text" id="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . ']" name="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . ']" value="' . esc_attr( $value ) . '" placeholder="' . esc_attr( $placeholder ) . '" />';
		$html    .= '<a href="#" class="button htl-uploader">' . esc_html__( 'Upload', 'hotelier' ) . '</a>';
		$html    .= '<label for="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . ']"> '  . wp_kses_post( $args[ 'desc' ] ) . '</label>';

		echo $html;
	}

	/**
	 * Print text-number input
	 */
	public function print_number( $html, $args ) {
		if ( isset( $this->options[ $args[ 'id' ] ] ) ) {
			$value = $this->options[ $args[ 'id' ] ];
		} else {
			$value = isset( $args[ 'std' ] ) ? $args[ 'std' ] : '';
		}

		$size     = ( isset( $args[ 'size' ] ) && ! is_null( $args[ 'size' ] ) ) ? $args[ 'size' ] : 'regular';
		$html     = '<input type="number" class="' . esc_attr( $size ) . '-text" id="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . ']" name="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . ']" value="' . esc_attr( $value ) . '" />';
		$html    .= '<label for="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . ']"> '  . wp_kses_post( $args[ 'desc' ] ) . '</label>';

		echo $html;
	}

	/**
	 * Print booking_hold_minutes (text-number) input
	 */
	public function print_booking_hold_minutes( $html, $args ) {
		if ( isset( $this->options[ $args[ 'id' ] ] ) ) {
			$value = $this->options[ $args[ 'id' ] ];
		} else {
			$value = isset( $args[ 'std' ] ) ? $args[ 'std' ] : '';
		}

		$size     = ( isset( $args[ 'size' ] ) && ! is_null( $args[ 'size' ] ) ) ? $args[ 'size' ] : 'regular';
		$html     = '<input type="number" class="' . esc_attr( $size ) . '-text" id="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . ']" name="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . ']" value="' . esc_attr( $value ) . '" />';
		$html    .= '<label for="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . ']"> '  . wp_kses_post( $args[ 'desc' ] ) . '</label>';

		echo $html;
	}

	/**
	 * Print select input
	 */
	public function print_select( $html, $args ) {
		if ( isset( $this->options[ $args[ 'id' ] ] ) ) {
			$value = $this->options[ $args[ 'id' ] ];
		} else {
			$value = isset( $args[ 'std' ] ) ? $args[ 'std' ] : '';
		}

		$html = '<select id="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . ']" name="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . ']">';

		foreach ( $args[ 'options' ] as $option => $name ) {
			$selected = selected( $option, $value, false );
			$html .= '<option value="' . esc_attr( $option ) . '" ' . $selected . '>' . esc_html( $name ) . '</option>';
		}

		$html .= '</select>';
		$html .= '<label for="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . ']"> '  . wp_kses_post( $args[ 'desc' ] ) . '</label>';

		echo $html;
	}

	/**
	 * Print checkbox input
	 */
	public function print_checkbox( $html, $args ) {
		if ( isset( $this->options[ $args[ 'id' ] ] ) ) {
			$value = $this->options[ $args[ 'id' ] ];
		} else {
			$value = isset( $args[ 'std' ] ) ? $args[ 'std' ] : '';
		}

		$html = '<input type="checkbox" id="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . ']" name="hotelier_settings[' . $args['id'] . ']" value="1" ' . checked( $value, 1, false ) . '/>';
		$html .= '<label for="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . ']"> '  . esc_html( $args[ 'desc' ] ) . '</label>';

		if ( $args[ 'subdesc' ] ) {
			$html .= '<p class="description subdesc"> '  . wp_kses_post( $args[ 'subdesc' ] ) . '</label>';
		}

		echo $html;
	}

	/**
	 * Print card_icons input
	 */
	public function print_card_icons( $html, $args ) {
		if ( isset( $this->options[ $args[ 'id' ] ] ) ) {
			$value = $this->options[ $args[ 'id' ] ];
		} else {
			$value = isset( $args[ 'std' ] ) ? $args[ 'std' ] : '';
		}

		foreach ( $args[ 'options' ] as $key => $option ) {
			if ( isset( $this->options[ $args[ 'id' ] ][ $key ] ) ) {
				$enabled = 1;
			} else {
				$enabled = NULL;
			}

			echo '<input name="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . '][' . esc_attr( $key ) . ']" id="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . '][' . esc_attr( $key ) . ']" class="card-icons" type="checkbox" value="1" ' . checked( 1, $enabled, false ) . ' />&nbsp;';

			// Extensions can use the ID of the 'span' to add the gateway icon with CSS
			echo '<label class="input-checkbox card-icons" for="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . '][' . esc_attr( $key ) . ']"><span class="hotelier-accepted-cards" id="hotelier-accepted-cards-' . esc_attr( $key ) . '">' . wp_kses_post( $option ) . '</span></label>';
		}

		echo '<div class="description cards-description">' . wp_kses_post( $args[ 'desc' ] ) . '</div>';
	}

	/**
	 * Print radio input
	 */
	public function print_radio( $html, $args ) {
		foreach ( $args[ 'options' ] as $key => $option ) {
			$checked = false;

			if ( isset( $this->options[ $args[ 'id' ] ] ) && $this->options[ $args[ 'id' ] ] == $key )
				$checked = true;
			elseif( isset( $args[ 'std' ] ) && $args[ 'std' ] == $key && ! isset( $this->options[ $args[ 'id' ] ] ) )
				$checked = true;

			echo '<input name="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . ']" id="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . '][' . esc_attr( $key ) . ']" type="radio" value="' . esc_attr( $key ) . '" ' . checked( true, $checked, false ) . '/>&nbsp;';
			echo '<label class="input-radio" for="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . '][' . esc_attr( $key ) . ']">' . wp_kses_post( $option ) . '</label><br/>';
		}

		echo '<div class="description radio-description">' . wp_kses_post( $args[ 'desc' ] ) . '</div>';
	}

	/**
	 * Print image_size input
	 */
	public function print_image_size( $html, $args ) {
		if ( isset( $this->options[ $args[ 'id' ] ] ) ) {
			$value = $this->options[ $args[ 'id' ] ];
		} else {
			$value = isset( $args[ 'std' ] ) ? $args[ 'std' ] : '';
		}

		$width   = $value[ 'width' ];
		$height  = $value[ 'height' ];
		$checked = isset( $this->options[ $args[ 'id' ] ][ 'crop' ] ) ? checked( 1, $this->options[ $args[ 'id' ] ][ 'crop' ], false ) : checked( 1, isset( $value[ 'crop' ] ), false );

		$html = '<input name="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . '][width]" id="' . esc_attr( $args[ 'id' ] ) . '-width" type="text" size="3" value="' . absint( $width ) . '" /> &times; <input name="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . '][height]" id="' . esc_attr( $args[ 'id' ] ) . '-height" type="text" size="3" value="' . absint( $height ) . '" />px';

		$html .= '<label><input name="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . '][crop]" id="' . esc_attr( $args[ 'id' ] ) . '-crop" type="checkbox" value="1" ' . $checked . ' />' . esc_html__( 'Hard Crop?', 'hotelier' ) . '</label>';

		echo $html;
	}

	/**
	 * Print from_to input
	 */
	public function print_from_to( $html, $args ) {
		if ( isset( $this->options[ $args[ 'id' ] ] ) ) {
			$value = $this->options[ $args[ 'id' ] ];
		} else {
			$value = isset( $args[ 'std' ] ) ? $args[ 'std' ] : '';
		}

		$from = $value[ 'from' ];
		$to   = $value[ 'to' ];

		$options = array(
			'0'  => '00:00',
			'1'  => '01:00',
			'2'  => '02:00',
			'3'  => '03:00',
			'4'  => '04:00',
			'5'  => '05:00 ',
			'6'  => '06:00',
			'7'  => '07:00',
			'8'  => '08:00',
			'9'  => '09:00',
			'10' => '10:00',
			'11' => '11:00',
			'12' => '12:00',
			'13' => '13:00',
			'14' => '14:00',
			'15' => '15:00',
			'16' => '16:00',
			'17' => '17:00',
			'18' => '18:00',
			'19' => '19:00',
			'20' => '20:00',
			'21' => '21:00',
			'22' => '22:00',
			'23' => '23:00'
		);

		$html = '<label class="from-to">' . esc_html__( 'From:', 'hotelier' ) . '<select name="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . '][from]">';

		foreach ( $options as $option => $name ) {
			$selected = selected( $option, $from, false );
			$html .= '<option value="' . esc_attr( $option ) . '" ' . $selected . '>' . esc_html( $name ) . '</option>';
		}

		$html .= '</select></label>';

		$html .= '<label class="from-to">' . esc_html__( 'To:', 'hotelier' ) . '<select name="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . '][to]">';

		foreach ( $options as $option => $name ) {
			$selected = selected( $option, $to, false );
			$html .= '<option value="' . esc_attr( $option ) . '" ' . $selected . '>' . esc_html( $name ) . '</option>';
		}

		$html .= '</select></label>';

		echo $html;
	}

	/**
	 * Print gateways input
	 */
	public function print_gateways( $html, $args ) {
		foreach ( $args[ 'options' ] as $option ) {
			$enabled = ( isset( $this->options[ 'payment_gateways' ][ esc_attr( $option[ 'id' ] ) ] ) ) ? '1' : null;

			$html = '<input name="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . '][' . $option[ 'id' ] . ']"" id="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . '][' . esc_attr( $option[ 'id' ] ) . ']" type="checkbox" value="1" ' . checked('1', $enabled, false) . '/>&nbsp;';
			$html .= '<label for="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . '][' . $option[ 'id' ] . ']">' . wp_kses_post( $option[ 'admin_label' ] ) . '</label><br/>';
			echo $html;
		}
	}

	/**
	 * Print gateways dropdown
	 */
	public function print_gateway_select( $html, $args ) {
		$html = '<select name="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . ']"" id="hotelier_settings[' . esc_attr( $args[ 'id' ] ) . ']">';

		foreach ( $args[ 'options' ] as $option ) {
			$selected = isset( $this->options[ $args[ 'id' ] ] ) ? selected( $option[ 'id' ], $this->options[ $args[ 'id' ] ], false ) : '';
			$html .= '<option value="' . esc_attr( $option[ 'id' ] ) . '"' . $selected . '>' . esc_html( $option[ 'admin_label' ] ) . '</option>';
		}

		echo $html;
	}

	/**
	 * Print button
	 */
	public function print_button( $html, $args ) {
		$html = '<p>';

		switch ( $args[ 'id' ] ) {
			case 'install_pages':
				$html .= '<a class="button" href="' . wp_nonce_url( admin_url( 'admin.php?page=hotelier-settings&tab=tools&action=install_pages' ), 'tools_action' ) . '">' . esc_html__( 'Install pages', 'hotelier' ) . '</a>';
				break;

			case 'send_test_email':
				$html .= '<a class="button" href="' . wp_nonce_url( admin_url( 'admin.php?page=hotelier-settings&tab=tools&action=send_test_email' ), 'tools_action' ) . '">' . esc_html__( 'Send email', 'hotelier' ) . '</a>';
				break;

			case 'clear_sessions':
				$html .= '<a class="button" href="' . wp_nonce_url( admin_url( 'admin.php?page=hotelier-settings&tab=tools&action=clear_sessions' ), 'tools_action' ) . '">' . esc_html__( 'Clear sessions', 'hotelier' ) . '</a>';
				break;

			case 'delete_completed_bookings':
				$html .= '<a class="button" href="' . wp_nonce_url( admin_url( 'admin.php?page=hotelier-settings&tab=tools&action=delete_completed_bookings' ), 'tools_action' ) . '">' . esc_html__( 'Delete bookings', 'hotelier' ) . '</a>';
				break;

			default:
				break;
		}


		$html .= '<span class="description"> '  . esc_html( $args[ 'desc' ] ) . '</span>';
		$html .= '</p>';

		echo $html;

		do_action( 'hotelier_settings_hook_' . $args[ 'id' ] );
	}

	/**
	 * Install pages
	 */
	public function install_pages() {
		if ( ! empty( $_GET[ 'action' ] ) && ! empty( $_REQUEST[ '_wpnonce' ] ) && wp_verify_nonce( $_REQUEST[ '_wpnonce' ], 'tools_action' ) ) {

			if ( $_GET[ 'action' ] == 'install_pages' ) {

				HTL_Install::create_pages();
				echo '<div class="updated"><p>' . esc_html__( 'All missing Hotelier pages was installed successfully.', 'hotelier' ) . '</p></div>';
			}
		}
	}

	/**
	 * Send test email
	 */
	public function send_test_email() {
		if ( ! empty( $_GET[ 'action' ] ) && ! empty( $_REQUEST[ '_wpnonce' ] ) && wp_verify_nonce( $_REQUEST[ '_wpnonce' ], 'tools_action' ) ) {

			if ( $_GET[ 'action' ] == 'send_test_email' ) {

				$to      = get_option( 'admin_email' );
				$subject = sprintf( esc_html__( 'Test email from %s', 'hotelier'), get_bloginfo( 'name', 'display' ) );
				$message = sprintf( esc_html__( "This test email proves that your WordPress installation at %s can send emails.\n\nSent: %s", "hotelier" ), esc_url( get_bloginfo( "url" ) ), date( "r" ) );
				$headers = 'Content-Type: text/plain';
				wp_mail( $to, $subject, $message, $headers );

				echo '<div class="updated"><p>' . sprintf( wp_kses( __( 'Email sent. This does not mean it has been delivered. See %s in the Codex for more information.', 'hotelier' ), array( 'a' => array( 'href' => array() ) ) ), '<a href="http://codex.wordpress.org/Function_Reference/wp_mail">wp_mail</a>' ) . '</p></div>';
			}
		}
	}

	/**
	 * Clear sessions
	 */
	public function clear_sessions() {
		if ( ! empty( $_GET[ 'action' ] ) && ! empty( $_REQUEST[ '_wpnonce' ] ) && wp_verify_nonce( $_REQUEST[ '_wpnonce' ], 'tools_action' ) ) {

			if ( $_GET[ 'action' ] == 'clear_sessions' ) {

				global $wpdb;

				$wpdb->query( "DELETE FROM {$wpdb->prefix}hotelier_sessions" );

				wp_cache_flush();

				echo '<div class="updated"><p>' . esc_html__( 'Sessions successfully cleared.', 'hotelier' ) . '</p></div>';
			}
		}
	}

	/**
	 * Delete completed bookings
	 */
	public function delete_completed_bookings() {
		if ( ! empty( $_GET[ 'action' ] ) && ! empty( $_REQUEST[ '_wpnonce' ] ) && wp_verify_nonce( $_REQUEST[ '_wpnonce' ], 'tools_action' ) ) {

			if ( $_GET[ 'action' ] == 'delete_completed_bookings' ) {

				global $wpdb;

				$date        = date( 'Y-m-d' );
				$booking_ids = $wpdb->get_col( $wpdb->prepare( "SELECT reservation_id FROM {$wpdb->prefix}hotelier_bookings WHERE checkout < %s", $date ) );

				if ( $booking_ids ) {

					foreach ( $booking_ids as $booking_id) {

						// Delete bookings from custom tables
						$wpdb->query( $wpdb->prepare( "DELETE FROM itemmeta USING {$wpdb->prefix}hotelier_reservation_itemmeta itemmeta INNER JOIN {$wpdb->prefix}hotelier_reservation_items items WHERE itemmeta.reservation_item_id = items.reservation_item_id and items.reservation_id = %d", $booking_id ) );
						$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}hotelier_reservation_items WHERE reservation_id = %d", $booking_id ) );
						$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}hotelier_rooms_bookings WHERE reservation_id = %d", $booking_id ) );
						$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}hotelier_bookings WHERE reservation_id = %d", $booking_id ) );

						// Delete post
						wp_delete_post( $booking_id, true );
					}
				}

				echo '<div class="updated"><p>' . esc_html__( 'Bookings successfully deleted.', 'hotelier' ) . '</p></div>';
			}
		}
	}

	/**
	 * Print info
	 */
	public function print_info( $html, $args ) {
		echo '<p class="server-info">';
		do_action( 'hotelier_settings_info_' . $args[ 'id' ] );
		echo '</p>';
	}

	/**
	 * Print server_info
	 */
	public function print_server_info() {
		$info = '<span>' . esc_html__( 'Not Available', 'hotelier' ) . '</span>';

		if ( isset( $_SERVER[ 'SERVER_SOFTWARE' ] ) && ! empty( $_SERVER[ 'SERVER_SOFTWARE' ] ) ) {
			$info = '<span class="info-success">' . $_SERVER[ 'SERVER_SOFTWARE' ] . '</span>';
		}

		echo $info;
	}

	/**
	 * Print php_version
	 */
	public function print_php_version() {
		$info = '<span>' . esc_html__( 'Not Available', 'hotelier' ) . '</span>';

		if ( function_exists( 'phpversion' ) ) {
			if ( version_compare( phpversion(), '5.3.0', '<' ) ) {
				$info = '<span class="info-error">' . sprintf( esc_html__( '%s - Hotelier requires at least PHP 5.3.0. Please update your PHP version.', 'hotelier' ), phpversion() ) . '</span>';
			} else {
				$info = '<span class="info-success">' . phpversion() . '</span>';
			}
		}

		echo $info;
	}

	/**
	 * Print wp_memory_limit
	 */
	public function print_wp_memory_limit() {
		$info = '<span>' . esc_html__( 'Not Available', 'hotelier' ) . '</span>';

		$memory = HTL_Formatting_Helper::notation_to_int( WP_MEMORY_LIMIT );

		if ( $memory < 67108864 ) {
			$info = '<span class="info-error">' . sprintf( esc_html__( '%s - We recommend setting memory to at least 64MB.', 'hotelier' ), size_format( $memory ) ) . '</span>';
		} else {
			$info = '<span class="info-success">' . size_format( $memory ) . '</span>';
		}

		echo $info;
	}

	/**
	 * Print php_post_max_size
	 */
	public function print_php_post_max_size() {
		$info = '<span>' . esc_html__( 'Not Available', 'hotelier' ) . '</span>';

		if ( function_exists( 'ini_get' ) ) {
			$info = '<span class="info-success">' . size_format( HTL_Formatting_Helper::notation_to_int( ini_get( 'post_max_size' ) ) ) . '</span>';
		}

		echo $info;
	}

	/**
	 * Print php_post_max_upload_size
	 */
	public function print_php_post_max_upload_size() {
		$info = '<span>' . esc_html__( 'Not Available', 'hotelier' ) . '</span>';

		$info = '<span class="info-success">' . size_format( wp_max_upload_size() ) . '</span>';

		echo $info;
	}

	/**
	 * Print php_time_limit
	 */
	public function print_php_time_limit() {
		$info = '<span>' . esc_html__( 'Not Available', 'hotelier' ) . '</span>';

		if ( function_exists( 'ini_get' ) ) {
			$info = '<span class="info-success">' . ini_get( 'max_execution_time' ) . '</span>';
		}

		echo $info;
	}

	/**
	 * Print php_max_input_vars
	 */
	public function print_php_max_input_vars() {
		$info = '<span>' . esc_html__( 'Not Available', 'hotelier' ) . '</span>';

		if ( function_exists( 'ini_get' ) ) {
			$info = '<span class="info-success">' . ini_get( 'max_input_vars' ) . '</span>';
		}

		echo $info;
	}

	/**
	 * Print fsockopen_cURL
	 */
	public function print_fsockopen_cURL() {
		if ( function_exists( 'fsockopen' ) && function_exists( 'curl_init' ) ) {
			$info = '<span class="info-success">' . esc_html__( 'Enabled', 'hotelier' ) . '</span>';
		} else {
			$info = '<span class="info-error">' . esc_html__( 'Your server does not have fsockopen or cURL enabled - PayPal IPN and other scripts which communicate with other servers will not work. Contact your hosting provider.', 'hotelier' ) . '</span>';
		}

		echo $info;
	}

	/**
	 * Print DOMDocument
	 */
	public function print_domdocument() {
		if ( class_exists( 'DOMDocument' ) ) {
			$info = '<span class="info-success">' . esc_html__( 'Enabled', 'hotelier' ) . '</span>';
		} else {
			$info = '<span class="info-error">' . esc_html__( 'Your server does not have the DOMDocument class enabled - Some extensions may not work without DOMDocument', 'hotelier' ) . '</span>';
		}

		echo $info;
	}

	/**
	 * Print log_directory_writable
	 */
	public function print_log_directory_writable() {
		if ( @fopen( HTL_LOG_DIR . 'test-log.log', 'a' ) ) {
			$info = '<span class="info-success">' . HTL_LOG_DIR . '</span>';
		} else {
			$info = sprintf( '<span class="info-error">' . wp_kses( __( 'To allow logging, make <code>%s</code> writable or define a custom <code>HTL_LOG_DIR</code>.', 'hotelier' ), array( 'code' => array() ) ) . '</span>', HTL_LOG_DIR );
		}

		echo $info;
	}

	/**
	 * Sanitize text input
	 */
	public function sanitize_text( $input ) {
		return sanitize_text_field( $input );
	}

	/**
	 * Sanitize select input
	 */
	public function sanitize_select( $input, $key ) {
		// Save hotelier pages in a separate option
		if ( $key == 'listing_page' ) {
			update_option( 'hotelier_listing_page_id', absint( $input ) );
		} else if ( $key == 'booking_page' ) {
			update_option( 'hotelier_booking_page_id', absint( $input ) );
		}

		return sanitize_text_field( $input );
	}

	/**
	 * Sanitize upload input
	 */
	public function sanitize_upload( $input ) {
		return esc_url( $input );
	}

	/**
	 * Sanitize email input
	 */
	public function sanitize_email( $input ) {
		if ( ! is_email( $input ) ) {
			return '';
		}

		return sanitize_text_field( $input );
	}

	/**
	 * Sanitize text-number input
	 */
	public function sanitize_number( $input ) {
		return absint( $input );
	}

	/**
	 * Sanitize booking_hold_minutes (text-number) input
	 */
	public function sanitize_booking_hold_minutes( $input ) {
		$input = absint( $input );

		wp_clear_scheduled_hook( 'hotelier_cancel_pending_reservations' );

		if ( $input > 0 ) {
			wp_schedule_single_event( time() + ( absint( $input ) * 60 ), 'hotelier_cancel_pending_reservations' );
		}

		return $input;
	}

	/**
	 * Sanitize image_size input
	 */
	public function sanitize_image_size( $input ) {
		return array_map( 'absint', $input );
	}
}

endif;

return new HTL_Admin_Settings_Fields();
