<?php
/**
 * Setup menus in WP admin.
 *
 * @author   Lollum
 * @category Admin
 * @package  Hotelier/Admin
 * @version  0.9.0
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'HTL_Admin_Menus' ) ) :

/**
 * HTL_Admin_Menus Class
 *
 * Creates the admin menu pages.
 */
class HTL_Admin_Menus {
	/**
	 * Constructor.
	 */
	public function __construct() {
		// Add menus
		add_action( 'admin_menu', array( $this, 'add_menu' ), 9 );
	}

	/**
	 * Add logs menu item
	 */
	public function add_menu() {
		add_submenu_page( 'hotelier-settings', esc_html__( 'Logs', 'hotelier' ),  esc_html__( 'Logs', 'hotelier' ) , 'manage_hotelier', 'hotelier-logs', array( $this, 'log_page' ) );

		add_submenu_page( 'hotelier-settings', esc_html__( 'Add New Reservation', 'hotelier' ),  esc_html__( 'Add Reservation', 'hotelier' ) , 'manage_hotelier', 'hotelier-add-reservation', array( $this, 'add_new_reservation' ) );
	}

	/**
	 * Init the Log page
	 */
	public function log_page() {
		HTL_Admin_Logs::output();
	}

	/**
	 * Init the Log page
	 */
	public function add_new_reservation() {
		HTL_Admin_New_Reservation::output();
	}
}

endif;

return new HTL_Admin_Menus();
