<?php
/**
 * Hotelier Admin Emails Class.
 *
 * @author   Lollum
 * @category Admin
 * @package  Hotelier/Admin
 * @version  0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'HTL_Admin_Emails' ) ) :

/**
 * HTL_Admin_Emails Class
 *
 * Creates the Emails page.
 */
class HTL_Admin_Emails {
	/**
	 * Emails page.
	 *
	 * Handles the display of the emails page in admin.
	 */
	public static function output() {
		include_once 'settings/views/html-admin-page-emails.php';
	}
}

endif;
