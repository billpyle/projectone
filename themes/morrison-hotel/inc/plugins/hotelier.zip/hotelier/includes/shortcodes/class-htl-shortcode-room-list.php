<?php
/**
 * Room List Shortcode Class.
 *
 * @author   Lollum
 * @category Shortcodes
 * @package  Hotelier/Classes
 * @version  0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'HTL_Shortcode_Room_List' ) ) :

/**
 * HTL_Shortcode_Room_List Class
 */
class HTL_Shortcode_Room_List {

	/**
	 * Get the shortcode content.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function get( $atts ) {
		return HTL_Shortcodes::shortcode_wrapper( array( __CLASS__, 'output' ), $atts );
	}

	/**
	 * Output the shortcode.
	 *
	 * @param array $atts
	 */
	public static function output( $atts ) {
		self::room_list( $atts );
	}

	/**
	 * Show the room list form
	 */
	private static function room_list( $atts ) {
		// Hide room list form when booking_mode is set to 'no-booking'
		if ( htl_get_option( 'booking_mode' ) != 'no-booking' ) {

			// Arrival date must be "XX" days from current date (default 0).
			$from     = htl_get_option( 'booking_arrival_date', 0 );
			$to       = $from + 1;

			$checkin  = ! is_null( HTL()->session->get( 'checkin' ) ) ? HTL()->session->get( 'checkin' ) :  date( 'Y-m-d', strtotime( "+$from days" ) );
			$checkout = ! is_null( HTL()->session->get( 'checkout' ) ) ? HTL()->session->get( 'checkout' ) : date( 'Y-m-d', strtotime( "+$to days" ) );

			HTL()->session->set( 'checkin', $checkin );
			HTL()->session->set( 'checkout', $checkout );

			htl_get_template( 'room-list/form-room-list.php', array( 'checkin' => $checkin, 'checkout' => $checkout ) );
		}
	}
}

endif;
