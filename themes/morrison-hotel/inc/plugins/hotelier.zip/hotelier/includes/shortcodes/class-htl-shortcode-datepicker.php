<?php
/**
 * Datepicker Shortcode Class.
 *
 * @author   Lollum
 * @category Shortcodes
 * @package  Hotelier/Classes
 * @version  0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'HTL_Shortcode_Datepicker' ) ) :

/**
 * HTL_Shortcode_Datepicker Class
 */
class HTL_Shortcode_Datepicker {

	/**
	 * Get the shortcode content.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function get( $atts ) {
		return HTL_Shortcodes::shortcode_wrapper( array( __CLASS__, 'output' ), $atts );
	}

	/**
	 * Output the shortcode.
	 *
	 * @param array $atts
	 */
	public static function output( $atts ) {
		self::datepicker( $atts );
	}

	/**
	 * Show the datepicker form
	 */
	private static function datepicker( $atts ) {

		// Arrival date must be "XX" days from current date (default 0).
		$from     = htl_get_option( 'booking_arrival_date', 0 );
		$to       = $from + 1;

		$checkin  = ! is_null( HTL()->session->get( 'checkin' ) ) ? HTL()->session->get( 'checkin' ) :  date( 'Y-m-d', strtotime( "+$from days" ) );
		$checkout = ! is_null( HTL()->session->get( 'checkout' ) ) ? HTL()->session->get( 'checkout' ) : date( 'Y-m-d', strtotime( "+$to days" ) );

		HTL()->session->set( 'checkin', $checkin );
		HTL()->session->set( 'checkout', $checkout );

		// Enqueue the datepicker scripts
		wp_enqueue_script( 'hotelier-init-datepicker' );

		htl_get_template( 'global/datepicker.php', array( 'checkin' => $checkin, 'checkout' => $checkout ) );
	}
}

endif;
