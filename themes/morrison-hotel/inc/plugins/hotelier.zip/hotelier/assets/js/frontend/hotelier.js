jQuery(function($) {

	'use strict';

	var HTL_Hotelier = {
		init: function() {
			this.book_now_button();
			this.show_room_meta();
			this.show_room_rates();
			this.show_price_breakdown();
		},

		// Show the quantity input and update the text button
		book_now_button: function() {
			var add_to_cart_button = $('form.room-list .add-to-cart-button');
			var qty_input          = $('form.room-list .quantity');

			qty_input.hide();

			add_to_cart_button.on('click', function(e) {
				e.preventDefault();

				var _this = $(this);
				var parent        = _this.closest('.add-to-cart');
				var qty           = parent.find('.quantity');
				var input         = qty.find('input.qty');

				if (!_this.hasClass('selected')) {
					var parent_room   = _this.closest('li.room');
					var selected_txt  = _this.data('selected-text-singular');
					var selected_html = '<span class="add-to-cart-selected"><span class="count">1</span> <span class="text">' + selected_txt + '</span></span>';

					parent_room.addClass('selected_room');
					_this.addClass('selected');
					_this.append(selected_html);
					input.val(1);
					qty.show();
				} else {
					if (parseInt(input.val()) > 0) {
						$('html, body').animate({
							scrollTop: $('#reserve-button').offset().top
						}, 600);
					}
				}
			});

			qty_input.on('change', function() {
				var _this       = $(this);
				var input       = _this.find('input.qty');
				var parent_room = _this.closest('li.room');
				var value       = parseInt(input.val());
				var button      = _this.closest('.add-to-cart').find('.add-to-cart-button');
				var count       = button.find('.count');
				var text        = button.find('.text');

				if (value === 1) {
					text.html(button.data('selected-text-singular'));
				} else {
					text.html(button.data('selected-text-plural'));

					if (isNaN(value)) {
						value = 0;
					}
				}

				count.html(value);

				if (value === 0) {
					parent_room.removeClass('selected_room');
				} else {
					parent_room.addClass('selected_room');
				}

			});
		},

		// Show/hide room details in the available rooms form (listing page)
		show_room_meta: function() {
			var room_meta        = $('form.room-list .room-meta-wrap');
			var room_meta_button = $('form.room-list .more-about-room').find('a');
			var open_text        = room_meta_button.data('open');
			var closed_text      = room_meta_button.data('closed');

			room_meta.hide();
			room_meta_button.text(closed_text);

			room_meta_button.on('click', function(e) {
				e.preventDefault();

				var _this   = $(this);
				var meta_id = _this.attr('href');
				var txt     = $(meta_id).is(':visible') ? closed_text : open_text;

				_this.text(txt);
				$(meta_id).toggle();
			});
		},

		// Show/hide room rates in the available rooms form (listing page)
		show_room_rates: function() {
			var room_variations        = $('form.room-list .room-variations');
			var room_variations_button = $('form.room-list .toggle-rates');
			var open_text              = room_variations_button.data('open');
			var closed_text            = room_variations_button.data('closed');

			room_variations.hide();
			room_variations_button.text(closed_text);

			room_variations_button.on('click', function(e) {
				e.preventDefault();

				var _this         = $(this);
				var variations_id = _this.attr('href');
				var txt           = $(variations_id).is(':visible') ? closed_text : open_text;

				_this.text(txt);
				$(variations_id).toggle();
			});
		},

		// Show/hide the price breakdown table
		show_price_breakdown: function() {
			var breakdown_tables = $('.reservation-table .price-breakdown-table');
			var breakdown_button = $('.reservation-table .view-price-breakdown');
			var open_text        = breakdown_button.data('open');
			var closed_text      = breakdown_button.data('closed');

			breakdown_tables.hide();
			breakdown_button.text(closed_text);

			breakdown_button.on('click', function(e) {
				e.preventDefault();

				var _this    = $(this);
				var table_id = _this.attr('href');
				var txt      = $(table_id).is(':visible') ? closed_text : open_text;

				_this.text(txt);
				$(table_id).toggle();
			});
		},
	};

	$(document).ready(function() {
		HTL_Hotelier.init();
	});
});
