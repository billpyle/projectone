jQuery(function($) {

	'use strict';
	/* global fecha, datepicker_params */

	var HTL_Hotelier_Datepicker = {
		init: function() {
			this.init_datepicker();
		},

		// Init Datepicker
		init_datepicker: function() {
			if (document.getElementById('hotelier-datepicker-select')) {
				fecha.i18n['monthNamesShort'] = datepicker_params.month_names_short;

				var date_select_input = $('#hotelier-datepicker-select');
				var checkin_input     = $('#hotelier-datepicker-checkin');
				var checkout_input    = $('#hotelier-datepicker-checkout');

				date_select_input.show();
				checkin_input.hide();
				checkout_input.hide();

				if (checkin_input.val() && checkout_input.val()) {
					var checkin_date            = new Date(checkin_input.val());
					var checkout_date           = new Date(checkout_input.val());
					var checkin_date_formatted  = fecha.format(checkin_date, datepicker_params.datepicker_format);
					var checkout_date_formatted = fecha.format(checkout_date, datepicker_params.datepicker_format);

					date_select_input.val(checkin_date_formatted + ' - ' + checkout_date_formatted);
				}

				$('#hotelier-datepicker-select').hotelDatePicker({
					startOfWeek: datepicker_params.start_of_week,
					startDate: datepicker_params.start_date,
					endDate: datepicker_params.end_date,
					container: '#hotelier-datepicker',
					i18n: datepicker_params.i18n,
					getValue: function() {
						if (checkin_input.val() && checkout_input.val()) {
							return checkin_input.val() + ' - ' + checkout_input.val();
						} else {
							return '';
						}
					},
					setValue: function(s,s1,s2) {
						var checkin_date            = new Date(s1);
						var checkout_date           = new Date(s2);
						var checkin_date_formatted  = fecha.format(checkin_date, datepicker_params.datepicker_format);
						var checkout_date_formatted = fecha.format(checkout_date, datepicker_params.datepicker_format);

						date_select_input.val(checkin_date_formatted + ' - ' + checkout_date_formatted);
						checkin_input.val(s1);
						checkout_input.val(s2);
					}
				});
			}
		},
	};

	$(document).ready(function() {
		HTL_Hotelier_Datepicker.init();
	});
});
