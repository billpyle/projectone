jQuery(function ($) {

	'use strict';

	/* global PhotoSwipe, PhotoSwipeUI_Default */

	var pswp = $('.pswp')[0];

	$('.room-gallery').each(function() {
		var _this     = $(this),
	        getItems  = function() {
	            var items = [];

	            _this.find('a.room-thumbnail').each(function() {
	                var href   = $(this).attr('href'),
	                    size   = $(this).data('size').split('x'),
	                    title  = $(this).attr('title'),
	                    width  = size[0],
	                    height = size[1];

	                var item = {
						src   : href,
						title : title,
						w     : width,
						h     : height
	                };

	                items.push(item);
	            });

	            return items;
	        };

	    var items = getItems();

	    _this.on('click', 'a.room-thumbnail, a.show-gallery', function(e) {
			e.preventDefault();

		    var index = $(this).data('index');
		    var options = {
		        index: parseInt(index),
		        showHideOpacity: true,
		        shareEl: false,
		        captionEl: true
		    };

		    // Initialize PhotoSwipe
		    var lightBox = new PhotoSwipe(pswp, PhotoSwipeUI_Default, items, options);
		    lightBox.init();
		});
	});
});
