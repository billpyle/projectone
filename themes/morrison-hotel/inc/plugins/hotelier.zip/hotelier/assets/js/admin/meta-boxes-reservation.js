jQuery(function ($) {

	'use strict';

	var HTL_Reservation_Meta = {
		init: function() {
			this.edit_guest_fields();
		},

		edit_guest_fields: function() {
			$('.edit-address').on('click', function(e) {
				e.preventDefault();

				var _this  = $(this);
				var parent = _this.closest('.reservation-data-column');
				var data   = parent.find('.guest-data');
				var fields = parent.find('.edit-fields');

				data.hide();
				fields.show();
			});
		}
	};

	$(document).ready(function() {
		HTL_Reservation_Meta.init();
	});
});
