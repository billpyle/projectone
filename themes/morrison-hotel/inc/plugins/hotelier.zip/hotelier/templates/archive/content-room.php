<?php
/**
 * The template for displaying room content within loops
 *
 * This template can be overridden by copying it to yourtheme/hotelier/archive/content-room.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $room, $hotelier_loop;

// Store loop count we're currently on
if ( empty( $hotelier_loop[ 'loop' ] ) ) {
	$hotelier_loop[ 'loop' ] = 0;
}

// Store column count for displaying the grid
if ( empty( $hotelier_loop[ 'columns' ] ) ) {
	$hotelier_loop[ 'columns' ] = apply_filters( 'loop_room_columns', 3 );
}

// Ensure visibility
if ( ! $room ) {
	return;
}

// Increase loop count
$hotelier_loop[ 'loop' ]++;

// Extra post classes
$classes = array();
if ( 0 == ( $hotelier_loop[ 'loop' ] - 1 ) % $hotelier_loop[ 'columns' ] || 1 == $hotelier_loop[ 'columns' ] ) {
	$classes[] = 'first';
}
if ( 0 == $hotelier_loop[ 'loop' ] % $hotelier_loop[ 'columns' ] ) {
	$classes[] = 'last';
}

?>

<li <?php post_class( $classes ); ?>>

	<?php
	/**
	 * hotelier_archive_item_room hook.
	 *
	 * @hooked hotelier_template_archive_room_image - 5
	 * @hooked hotelier_template_archive_room_title - 10
	 * @hooked hotelier_template_archive_room_description - 20
	 * @hooked hotelier_template_archive_room_price - 30
	 * @hooked hotelier_template_archive_room_more - 40
	 */
	do_action( 'hotelier_archive_item_room' );
	?>

</li>
