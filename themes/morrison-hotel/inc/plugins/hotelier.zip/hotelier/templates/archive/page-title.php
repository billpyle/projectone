<?php
/**
 * The template for displaying the archive page title
 *
 * This template can be overridden by copying it to yourtheme/hotelier/archive/page-title.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<header class="page-header">
	<h1 class="page-title"><?php echo $page_title; ?></h1>
</header>
