<?php
/**
 * Archive Loop Wrapper Start
 *
 * This template can be overridden by copying it to yourtheme/hotelier/loop/loop-wrapper-start.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

// Store column count for displaying the grid
if ( empty( $hotelier_loop[ 'columns' ] ) ) {
	$hotelier_loop[ 'columns' ] = apply_filters( 'loop_room_columns', 3 );
}

?>

<div class="columns-<?php echo absint( $hotelier_loop[ 'columns' ] ); ?>">
