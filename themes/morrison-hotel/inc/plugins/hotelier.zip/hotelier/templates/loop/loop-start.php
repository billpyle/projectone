<?php
/**
 * Room Loop End
 *
 * This template can be overridden by copying it to yourtheme/hotelier/loop/loop-start.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>

<ul class="rooms">
