<?php
/**
 * Reservation item details
 *
 * This template can be overridden by copying it to yourtheme/hotelier/reservation/item.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<tr>
	<td class="room-name"><?php
		$is_visible = $room && $room->is_visible( true );

		echo $is_visible ? sprintf( '<a href="%s">%s</a>', get_permalink( $item[ 'room_id' ] ), $item[ 'name' ] ) : $item[ 'name' ];

		if ( isset( $item[ 'rate_name' ] ) ) : ?>
			<small><?php printf( esc_html__( 'Rate: %s', 'hotelier' ), htl_get_formatted_room_rate( $item[ 'rate_name' ] ) ); ?></small>
		<?php endif;

		// Allow other plugins to add additional room information here
		do_action( 'hotelier_reservation_item_meta', $item_id, $item, $reservation );
		?>
	</td>
	<td class="room-qty"><?php echo esc_html( $item[ 'qty' ] ); ?></td>
	<td class="room-cost"><?php echo $reservation->get_formatted_line_total( $item ); ?></td>
</tr>
