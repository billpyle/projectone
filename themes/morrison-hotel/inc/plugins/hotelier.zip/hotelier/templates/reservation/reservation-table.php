<?php
/**
 * Reservation table
 *
 * This template can be overridden by copying it to yourtheme/hotelier/reservation/reservation-table.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$reservation = htl_get_reservation( $reservation_id );

?>

<header><h3><?php esc_html_e( 'Reservation Details', 'hotelier' ); ?></h3></header>

<table class="reservation-table hotelier-table">
	<thead>
		<tr>
			<th class="room-name"><?php esc_html_e( 'Room', 'hotelier' ); ?></th>
			<th class="room-qty"><?php esc_html_e( 'Qty', 'hotelier' ); ?></th>
			<th class="room-cost"><?php esc_html_e( 'Cost', 'hotelier' ); ?></th>
		</tr>
	</thead>
	<tbody>
		<?php
			foreach( $reservation->get_items() as $item_id => $item ) {
				$room = $reservation->get_room_from_item( $item );

				htl_get_template( 'reservation/item.php', array(
					'reservation' => $reservation,
					'item_id'     => $item_id,
					'item'        => $item,
					'room'        => $room,
				) );
			}
		?>
	</tbody>
	<tfoot>
		<?php
		if ( $totals = $reservation->get_reservation_totals() ) :
			foreach ( $totals as $total ) : ?>
				<tr>
					<th colspan="2"><?php echo esc_html( $total[ 'label' ] ); ?></th>
					<td><strong><?php echo $total[ 'value' ]; ?></strong></td>
				</tr>
			<?php endforeach;
		endif; ?>
	</tfoot>
</table>

<?php do_action( 'hotelier_after_reservation_table', $reservation ); ?>

<?php htl_get_template( 'reservation/guest-details.php', array( 'reservation' =>  $reservation ) ); ?>
