<?php
/**
 * Rooms left message
 *
 * This template can be overridden by copying it to yourtheme/hotelier/room-list/rooms-left.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $room;

$checkin                 = HTL()->session->get( 'checkin' );
$checkout                = HTL()->session->get( 'checkout' );
$available_rooms         = absint( $room->get_available_rooms( $checkin, $checkout ) );
$low_room_threshold      = htl_get_option( 'low_room_threshold', 2 );
$show_left_rooms_message = ( $available_rooms <= $low_room_threshold ) ? true : false;

?>

<?php if ( apply_filters( 'hotelier_show_left_rooms_message', $show_left_rooms_message ) ) : ?>
	<mark class="only-x-left"><?php echo sprintf( _n( '%s room left!', '%s rooms left!', $available_rooms, 'hotelier' ), $available_rooms ); ?></mark>
<?php endif; ?>
