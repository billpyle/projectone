<?php
/**
 * Room rate description
 *
 * This template can be overridden by copying it to yourtheme/hotelier/room-list/rate/rate-description.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( $description = $variation->get_room_description() ) : ?>

<div class="rate-description"><?php echo wp_kses( $variation->get_room_description(), array( 'p' => array() ) ); ?></div>

<?php endif; ?>
