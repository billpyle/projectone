<?php
/**
 * Room max guests
 *
 * This template can be overridden by copying it to yourtheme/hotelier/room-list/max-guests.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $room;

$max_guests = $room->get_max_guests();

?>

<div class="room-max-guests">
	<strong><?php esc_html_e( 'Guests:', 'hotelier' ); ?></strong> <span class="max max<?php echo absint( $max_guests ); ?>"><?php echo absint( $max_guests ); ?></span>
</div>
