<?php
/**
 * Room conditions
 *
 * This template can be overridden by copying it to yourtheme/hotelier/room-list/room-conditions.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $room;

if ( ! $room->has_conditions() ) {
	return;
}

?>

<div class="room-conditions">

	<strong><?php esc_html_e( 'Room Conditions:', 'hotelier' ) ?></strong>

	<ul>

	<?php foreach ( $room->get_room_conditions() as $condition ) : ?>

		<li><?php echo esc_html( $condition ); ?></li>

	<?php endforeach; ?>

	</ul>

</div>
