<?php
/**
 * Room short description
 *
 * This template can be overridden by copying it to yourtheme/hotelier/room-list/short-description.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $post;

if ( ! $post->post_excerpt ) {
	return;
}

?>

<div class="room-description">
	<?php echo apply_filters( 'hotelier_short_description', $post->post_excerpt ) ?>
</div>

<p class="more-about-room"><a href="#room-meta-<?php echo esc_attr( $post->ID ); ?>" data-closed="<?php esc_html_e( 'More about this room', 'hotelier' ); ?>" data-open="<?php esc_html_e( 'Hide room details', 'hotelier' ); ?>"><?php esc_html_e( 'More about this room', 'hotelier' ); ?></a></p>
