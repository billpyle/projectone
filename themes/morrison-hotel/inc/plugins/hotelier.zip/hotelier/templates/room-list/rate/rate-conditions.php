<?php
/**
 * Room rate conditions
 *
 * This template can be overridden by copying it to yourtheme/hotelier/room-list/rate/rate-conditions.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! $variation->has_conditions() ) {
	return;
}

?>

<div class="room-conditions">

	<strong><?php esc_html_e( 'Room Conditions:', 'hotelier' ) ?></strong>

	<ul>

	<?php foreach ( $variation->get_room_conditions() as $condition ) : ?>

		<li><?php echo esc_html( $condition ); ?></li>

	<?php endforeach; ?>

	</ul>

</div>
