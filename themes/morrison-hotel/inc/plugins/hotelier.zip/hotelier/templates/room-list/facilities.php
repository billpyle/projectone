<?php
/**
 * Room facilities
 *
 * This template can be overridden by copying it to yourtheme/hotelier/room-list/facilities.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $room;

?>

<?php if ( $facilities = $room->get_facilities() ) : ?>

<div class="room-meta">

	<p><strong><?php esc_html_e( 'Room Facilities:', 'hotelier' ); ?></strong> <?php echo $facilities; ?></p>

</div>

<?php endif; ?>
