<?php
/**
 * Datepicker form
 *
 * This template can be overridden by copying it to yourtheme/hotelier/global/datepicker.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// extensions can hook into here to add their own pages
$datepicker_form_url = apply_filters( 'hotelier_datepicker_form_url', HTL()->cart->get_room_list_form_url() ); ?>

<form name="hotelier_datepicker" method="post" id="hotelier-datepicker" class="hotelier-datepicker" action="<?php echo esc_url( $datepicker_form_url ); ?>" enctype="multipart/form-data">

	<span class="select-icon"><input type="text" id="hotelier-datepicker-select" value=""></span>
	<input type="text" id="hotelier-datepicker-checkin" class="hotelier-datepicker checkin" name="checkin" value="<?php echo esc_attr( $checkin ); ?>">
	<input type="text" id="hotelier-datepicker-checkout" class="hotelier-datepicker checkout" name="checkout" value="<?php echo esc_attr( $checkout ); ?>">

	<?php echo apply_filters( 'hotelier_datepicker_button_html', '<input type="submit" class="button" name="hotelier_datepicker_button" id="datepicker-button" value="' . esc_attr__( 'Check Availability', 'hotelier' ) . '" />' ); ?>
</form>
