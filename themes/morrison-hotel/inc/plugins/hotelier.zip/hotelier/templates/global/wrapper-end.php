<?php
/**
 * Content wrappers
 *
 * This template can be overridden by copying it to yourtheme/hotelier/global/wrapper-end.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$template = get_option( 'template' );

switch( $template ) {
	case 'twentyfifteen' :
		echo '</main></div>';
		break;
	default :
		echo '</main></div>';
		break;
}
