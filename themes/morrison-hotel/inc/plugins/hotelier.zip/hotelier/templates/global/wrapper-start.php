<?php
/**
 * Content wrappers
 *
 * This template can be overridden by copying it to yourtheme/hotelier/global/wrapper-start.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$template = get_option( 'template' );

switch( $template ) {
	case 'twentyfifteen' :
		echo '<div id="primary" class="content-area twentyfifteen"><main id="main" class="site-main" role="main">';
		break;
	default :
		echo '<div id="primary" class="content-area"><main id="main" class="site-main" role="main">';
		break;
}
