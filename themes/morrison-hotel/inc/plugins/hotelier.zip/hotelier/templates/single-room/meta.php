<?php
/**
 * Room meta.
 *
 * This template can be overridden by copying it to yourtheme/hotelier/single-room/meta.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $room;

?>

<div class="room-meta">

	<h3><?php esc_html_e( 'Room Details', 'hotelier' ); ?></h3>

	<ul>
		<li><strong><?php esc_html_e( 'Guests:', 'hotelier' ); ?></strong> <?php echo absint( $room->get_max_guests() ); ?></li>

		<?php if ( $room->get_max_children() ) : ?>
			<li><strong><?php esc_html_e( 'Children:', 'hotelier' ); ?></strong> <?php echo absint( $room->get_max_guests() ); ?></li>
		<?php endif; ?>

		<?php if ( $room->get_formatted_room_size() ) : ?>
			<li><strong><?php esc_html_e( 'Room Size:', 'hotelier' ); ?></strong> <?php echo esc_html( $room->get_formatted_room_size() ); ?></li>
		<?php endif; ?>

		<?php if ( $room->get_bed_size() ) : ?>
			<li><strong><?php esc_html_e( 'Bed Size(s):', 'hotelier' ) ?></strong> <?php echo esc_html( $room->get_bed_size() ); ?></li>
		<?php endif; ?>

		<?php echo $room->get_categories( ', ', '<li><strong>' . esc_html__( 'Room Type:', 'hotelier' ) . '</strong> ', '</li>' ); ?>
	</ul>

</div>
