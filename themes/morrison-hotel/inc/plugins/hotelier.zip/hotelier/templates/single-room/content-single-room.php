<?php
/**
 * The template for displaying room content in the single-room.php template
 *
 * This template can be overridden by copying it to yourtheme/hotelier/single-room/content-single-room.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<?php
	/**
	 * hotelier_before_single_room hook.
	 *
	 * @hooked htl_print_notices - 10
	 */
	do_action( 'hotelier_before_single_room' );

	if ( post_password_required() ) {
		echo get_the_password_form();
		return;
	}
?>

<div id="room-<?php echo absint( get_the_ID() ); ?>" <?php post_class(); ?>>

	<?php
		/**
		 * hotelier_single_room_title hook.
		 *
		 * @hooked hotelier_template_single_room_title - 10
		 */
		do_action( 'hotelier_single_room_title' );
	?>

	<?php
		/**
		 * hotelier_single_room_images hook.
		 *
		 * @hooked hotelier_template_single_room_image - 10
		 * @hooked hotelier_template_single_room_gallery - 20
		 */
		do_action( 'hotelier_single_room_images' );
	?>

	<div class="entry-content">

		<div class="room-details">

			<?php
				/**
				 * hotelier_single_room_details hook.
				 *
				 * @hooked hotelier_template_single_room_datepicker - 5
				 * @hooked hotelier_template_single_room_price - 10
				 * @hooked hotelier_template_single_room_deposit - 20
				 * @hooked hotelier_template_single_room_meta - 30
				 * @hooked hotelier_template_single_room_facilities - 40
				 * @hooked hotelier_template_single_room_conditions - 50
				 * @hooked hotelier_template_single_room_sharing - 60
				 */
				do_action( 'hotelier_single_room_details' );
			?>

		</div>

		<div class="room-description">

			<?php
				/**
				 * hotelier_single_room_description hook.
				 *
				 * @hooked hotelier_template_single_room_description - 10
				 */
				do_action( 'hotelier_single_room_description' );
			?>

		</div>

		<?php
			/**
			 * hotelier_single_room_rates hook.
			 *
			 * @hooked hotelier_template_single_room_rates - 10
			 */
			do_action( 'hotelier_single_room_rates' );
		?>

		<?php
			/**
			 * hotelier_output_related_rooms hook.
			 *
			 * @hooked hotelier_template_related_rooms - 10
			 */
			do_action( 'hotelier_output_related_rooms' );
		?>

	</div>
</div>
