<?php
/**
 * Room image.
 *
 * This template can be overridden by copying it to yourtheme/hotelier/single-room/image.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// The .post-thumbnail div is closed in single-room/gallery.php!

?>

<div class="post-thumbnail">

	<?php
		if ( has_post_thumbnail() ) {
			the_post_thumbnail( 'room_single' );

		} else {

			echo htl_placeholder_img( 'room_single' );
		}
	?>
