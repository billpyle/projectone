<?php
/**
 * Room sharer.
 *
 * This template can be overridden by copying it to yourtheme/hotelier/single-room/sharer.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<?php do_action( 'hotelier_room_sharer' ); ?>
