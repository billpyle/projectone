<?php
/**
 * Request Booking
 *
 * This template can be overridden by copying it to yourtheme/hotelier/booking/book-button.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<div id="request-booking">

	<div class="form-row">
		<?php do_action( 'hotelier_booking_before_submit' ); ?>

		<?php echo apply_filters( 'hotelier_book_button_html', '<input type="submit" class="button" name="hotelier_booking_book_button" id="book-button" value="' . esc_attr( $button_text ) . '" />' ); ?>

		<?php do_action( 'hotelier_booking_after_submit' ); ?>

		<?php wp_nonce_field( 'hotelier_process_booking' ); ?>
	</div>

</div>
