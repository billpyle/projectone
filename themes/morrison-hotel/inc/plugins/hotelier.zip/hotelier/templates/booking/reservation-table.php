<?php
/**
 * Booking table
 *
 * This template can be overridden by copying it to yourtheme/hotelier/booking/reservation-table.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<div id="booking-table">

	<header><h3><?php esc_html_e( 'Your Reservation', 'hotelier' ); ?></h3></header>

	<?php do_action( 'hotelier_booking_before_booking_table' ); ?>

	<table class="reservation-table hotelier-table">
		<thead>
			<tr>
				<th class="room-name"><?php esc_html_e( 'Room', 'hotelier' ); ?></th>
				<th class="room-qty"><?php esc_html_e( 'Qty', 'hotelier' ); ?></th>
				<th class="room-cost"><?php esc_html_e( 'Cost', 'hotelier' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php
				foreach ( HTL()->cart->get_cart() as $cart_item_key => $cart_item ) :
					$_room    = $cart_item[ 'data' ];
					$_room_id = $cart_item[ 'room_id' ];

					if ( $_room && $_room->exists() && $cart_item[ 'quantity' ] > 0 ) : ?>

						<tr>
							<td class="room-name">

								<a href="<?php echo esc_url( get_permalink( $_room_id ) ); ?>"><?php echo esc_html( $_room->get_title() ); ?></a>

								<?php if ( $cart_item[ 'rate_name' ] ) : ?>
									<small><?php printf( esc_html__( 'Rate: %s', 'hotelier' ), htl_get_formatted_room_rate( $cart_item[ 'rate_name' ] ) ); ?></small>
								<?php endif; ?>

							</td>

							<td class="room-qty"><?php echo absint( $cart_item[ 'quantity' ] ); ?></td>
							<td class="room-cost">
								<?php echo HTL()->cart->get_room_price( $cart_item[ 'total' ] ); ?>

								<?php if ( $nights > 1 ) : ?>
								<a class="view-price-breakdown" href="#<?php echo esc_attr( htl_generate_item_key( $cart_item[ 'room_id' ], $cart_item[ 'rate_id' ] ) ); ?>" data-closed="<?php esc_html_e( 'View price breakdown', 'hotelier' ); ?>" data-open="<?php esc_html_e( 'Hide price breakdown', 'hotelier' ); ?>"><?php echo esc_html_e( 'View price breakdown', 'hotelier' ); ?></a>
								<?php endif; ?>
							</td>


						</tr>

						<?php if ( $nights > 1 ) : ?>
						<tr>
							<td colspan="3" class="price_breakdown_td">
								<?php echo htl_cart_price_breakdown( HTL()->session->get( 'checkin' ), HTL()->session->get( 'checkout' ), $cart_item[ 'room_id' ], $cart_item[ 'rate_id' ], $cart_item[ 'quantity' ] ); ?>
							</td>
						</tr>
						<?php endif;

					endif;
				endforeach;
			?>

		</tbody>
		<tfoot>
			<?php
				if ( HTL()->cart->needs_payment() ) : ?>

					<tr>
						<th colspan="2"><?php esc_html_e( 'Total:', 'hotelier' ); ?></th>
						<td><strong><?php echo htl_cart_formatted_total(); ?></strong></td>
					</tr>

					<?php if ( htl_get_option( 'booking_mode' ) == 'instant-booking' ) : ?>

						<tr>
							<th colspan="2"><?php esc_html_e( 'Deposit Due Now:', 'hotelier' ); ?></th>
							<td><strong><?php echo htl_cart_formatted_required_deposit(); ?></strong></td>
						</tr>

					<?php else : ?>

						<tr>
							<th colspan="2"><?php esc_html_e( 'Deposit Due After Confirm:', 'hotelier' ); ?></th>
							<td><strong><?php echo htl_cart_formatted_required_deposit(); ?></strong></td>
						</tr>

					<?php endif; ?>

				<?php else : ?>

					<tr>
						<th colspan="2"><?php esc_html_e( 'Total:', 'hotelier' ); ?></th>
						<td><strong><?php echo htl_cart_formatted_total(); ?></strong></td>
					</tr>

				<?php endif;
			?>
		</tfoot>
	</table>

	<?php do_action( 'hotelier_booking_after_booking_table' ); ?>

</div>
