<?php
/**
 * Output a single payment method
 *
 * This template can be overridden by copying it to yourtheme/hotelier/booking/payment-method.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<li class="payment-method-<?php echo $gateway->id; ?> <?php echo $single ? 'single' : '' ?>">
	<input id="payment-method_<?php echo $gateway->id; ?>" type="radio" class="input-radio" name="payment_method" value="<?php echo esc_attr( $gateway->id ); ?>" <?php checked( $gateway->selected, true ); ?> />

	<label for="payment-method-<?php echo $gateway->id; ?>">
		<?php echo $gateway->get_title(); ?> <?php echo $gateway->get_icon(); ?>
	</label>

</li>
