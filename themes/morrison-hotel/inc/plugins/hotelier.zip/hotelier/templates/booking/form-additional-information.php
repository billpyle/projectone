<?php
/**
 * Additional Information Form
 *
 * This template can be overridden by copying it to yourtheme/hotelier/booking/form-additional-information.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<div id="guest-additional-information">

	<header><h3><?php esc_html_e( 'Additional Information', 'hotelier' ); ?></h3></header>

	<?php do_action( 'hotelier_booking_before_additional_information' ); ?>

	<div class="hotelier-additional-information-fields">

		<?php foreach ( $booking->booking_fields[ 'additional_information_fields' ] as $key => $field ) : ?>

			<?php htl_form_field( $key, $field, $booking->get_value( $key ) ); ?>

		<?php endforeach; ?>

	</div>

	<?php do_action( 'hotelier_booking_after_additional_information' ); ?>

</div>
