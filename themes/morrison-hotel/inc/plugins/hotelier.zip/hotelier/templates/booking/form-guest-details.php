<?php
/**
 * Guest Details Form
 *
 * This template can be overridden by copying it to yourtheme/hotelier/booking/form-guest-details.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<div id="guest-details">

	<header><h3><?php esc_html_e( 'Guest Details', 'hotelier' ); ?></h3></header>

	<?php do_action( 'hotelier_booking_before_guest_details' ); ?>

	<div class="hotelier-details-fields">

		<?php foreach ( $booking->booking_fields[ 'address_fields' ] as $key => $field ) : ?>

			<?php htl_form_field( $key, $field, $booking->get_value( $key ) ); ?>

		<?php endforeach; ?>

	</div>

	<?php do_action( 'hotelier_booking_after_guest_details' ); ?>

</div>
